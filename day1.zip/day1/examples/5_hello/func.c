#include <linux/kernel.h>
void func(void)
{
	printk(KERN_INFO"Hello Linux\n");
}

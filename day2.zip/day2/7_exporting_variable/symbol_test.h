#ifndef _SYMBOL_H
#define _SYMBOL_H

struct test
{
    int a;
    int b;
    int c;
    int d;
    char e;
};

extern struct test foo;

#endif 

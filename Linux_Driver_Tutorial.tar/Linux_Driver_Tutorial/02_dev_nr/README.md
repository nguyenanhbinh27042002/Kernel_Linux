To run this example create a device file with:


~~~~~
sudo mknod /dev/mydevice c 64 0

~~~~~


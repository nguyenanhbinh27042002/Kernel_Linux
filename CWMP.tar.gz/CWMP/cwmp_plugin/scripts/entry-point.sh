#!/bin/sh
export WORK_DIR=/tmp/dev/package/deploy
$WORK_DIR/scripts/setup_all.sh $1
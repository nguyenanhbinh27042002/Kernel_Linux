#!/bin/sh
export WORK_DIR=/tmp/dev/package/deploy
export SOCK_DIR=/tmp/mqtt_info/sock
export LD_LIBRARY_PATH=$WORK_DIR/lib:/usr/mqtt/lib          
BUSYBOX_CMD=$WORK_DIR/bin/busybox
EXEC_DIR=$WORK_DIR/bin/cts_plugin
SCRIPT_PATH=$WORK_DIR/script
PID_FILE=$WORK_DIR/run/cts.pid

echo $BUSYBOX_CMD
echo $EXEC_DIR
echo $SCRIPT_PATH
echo $PID_FILE

# -S: start
# -b: background
# -q: quiet
# -m: make-pidfile
# -p: pidfile
# -v: version
# -x: exec

NOTIFY_URL="http://cpek.fpt.vn/plugin-history"
NOTIFY_AUTH="cpelablog:tRePRoWnPotHEDaYeRyArtEdOryDrifloAroGiBliOnjEcOMna"

post_notify_data() {
    MAC=$(ifconfig eth0 | grep HWaddr | awk '{print tolower($5)}')
    /usr/bin/curl -X POST -d "{\"mac_cpe\":\"$MAC\",\"plugin_name\":\"cts_info\",\"status\":$@}" -H "Content-Type: application/json" -u $NOTIFY_AUTH $NOTIFY_URL
}

run_cts_plugin() {
    export LD_LIBRARY_PATH=$WORK_DIR/lib:/usr/mqtt/lib
    echo "start run daemon cts_plugin"
    $BUSYBOX_CMD start-stop-daemon -S -b -q -m -p -c admin $PID_FILE -v -x $EXEC_DIR
}

start() {
    if [ ! -f $PID_FILE ]
    then
        post_notify_data "true"
        run_cts_plugin
    else
        PID=$(cat $PID_FILE)
        if [ ! -d /proc/$PID ]
        then
            run_cts_plugin
        fi
    fi
}

stop() {
    if [ -f $PID_FILE ]
    then
        PID=$(cat $PID_FILE)
        if [ -d /proc/$PID ]
        then
            post_notify_data "false"
            kill -9 $PID
        fi
        rm -f $PID_FILE
    fi
}

# setup folder and file
mkdir -p $WORK_DIR/tmp
mkdir -p $WORK_DIR/cache
touch $WORK_DIR/tmp/sock.client

if [ -e $WORK_DIR/tmp/sock.client ]
then
    echo >> $WORK_DIR/tmp/sock.client
fi


case "$1" in
    start)
        start
    ;;
    
    stop)
        stop
    ;;
    
    restart|reload|force-reload)
        $0 stop
        $0 start
    ;;
    
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload}"
        exit 2
    ;;
esac

exit $?
#ifndef __SELF_TASK_H__
#define __SELF_TASK_H__

#include "ak/ak.h"
#include "task_list.h"

extern void *task_app_self_entry(void);
extern q_msg_t gw_task_app_self_mailbox;

#endif
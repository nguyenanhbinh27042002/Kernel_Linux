#ifndef __UTILS_H__
#define __UTILS_H__

#include <net/if.h>
#include <errno.h>
#include <string.h>
#include <jansson.h>
#include <pthread.h>

#ifndef __AK_PACKETED
#define __AK_PACKETED __attribute__((__packed__))
#endif

typedef struct {
	int register_timer;
	int push_kafka_timer;
	int info_manager_timer;
	int internet_manager_timer;
	int self_control_timer;
}__AK_PACKETED cron_job_config_t;

typedef struct {
	char ca[100];
	char kafka[100];
	char user[100];
	char pass[100];
}__AK_PACKETED service_config_t;

char *execute_command(char *cmd);
void append(char subject[], const char insert[], int pos);
void *execute_command_pointer(char *cmd, char *data);
int get_channel_by_fre(int fre) ;
void append_character(char* s, char c);
long long get_current_timestamp();
int get_app_memory();
void store_to_cache(char* path, json_t* log);
char *execute_command_ubus(char *cmd);
unsigned long get_unix_timestamp();
int is_file_path_exist(char* filePath) ;
int remove_file(char* filePath);
#endif
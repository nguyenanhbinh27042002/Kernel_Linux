#ifndef __JSON_PACKAGE_H__
#define __JSON_PACKAGE_H__

char* clients_json_package_ptr();
char* interface_stat_package_ptr();
char* network_info_package_ptr();
char* system_info_package_ptr();
char* temperature_info_package_ptr();
char* network_topology_package_ptr();
// ubus topic support function 
char* get_json_response(int topic_id);
#endif
#ifndef __UBUS_MAPPING_H__
#define __UBUS_MAPPING_H__

enum ubus_topic_mapping {
	GET_SYSTEM_INFO = 0	,
	GET_INTERFACE_STAT	,
	GET_NETWORK_INFO	,
	GET_CLIENT_INFO		,
	GET_TEMP_HISTORY	,
	GET_TOPOLOGY		,
	MAX_GET_TOPIC		,

	SET_REBOOT			,
	DOWNLOAD_FIRMWARE 	,
	UPGRADE_FIRMWARE 	,
	MAX_SET_TOPIC		,
	
	MAX_TOPIC			,
	UBUS_REPLY			
};

enum task_index {
	GET_INDEX,
	SET_INDEX,
	MAX_INDEX,
};

int get_dest_task_handler_index(int msg_id);
#endif
#ifndef __TASK_LIST_H__
#define __TASK_LIST_H__
#include "ak/ak.h"
#include "unix_socket_task.h"
#include "set_task.h"
#include "get_task.h"
#include "reply_task.h"
#include "self_task.h"
enum
{
    DEFAULT_AT_FIRST_TASK = AK_TASK_TIMER_ID,
    /* APP TASK LIST BEGIN*/
    TASK_APP_UNIX_SOCKET    ,
    TASK_APP_SET            ,
    TASK_APP_GET            ,
    TASK_REPLY              ,
    TASK_SELF               ,
    /* EOT task ID*/
    AK_TASK_LIST_LEN        ,
};

extern ak_task_t task_list_init[];

#endif
#ifndef __RC_CODE_H__
#define __RC_CODE_H__

#define     RC_SUCCESS                  0
#define     RC_JSON_ERROR               -1
#define     RC_ACTION_NOT_IMPLEMENT     -2
#define     RC_SOCKET_ERROR             -3
#define     RC_DATA_EMTPY               -4
#define     RC_FAIL_TO_RM_FILE          -5
#define     RC_FAIL_EXEC_WGET_FILE      -6
#define     RC_FAIL_DL_FILE             -7
#define     RC_FAIL_TO_FREE_UP_RAM      -8
#define     RC_RC_RAM_NOT_ENOUGH        -9
#define     RC_AGENT_NOT_SUPPORT        -10

#endif
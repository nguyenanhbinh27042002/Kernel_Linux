#ifndef __IPC_H__
#define __IPC_H__

#define SERVER_UNIX_SOCKET_PATH "%s/tmp/sock"
#define CLIENT_UNIX_SOCKET_PATH "%s/tmp/sock.client"

#include <errno.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>

#define TOPIC_NAME "unix_plugin"
#define EXIT true
#define NOEXIT false
#define NO_SOCK 999
#define ERROR_CODE -1

#define SOCK_DIR_ENV        "SOCK_DIR"

#define ERROR_MSG_CODE      -1
#define MSG_ID              "message_id"
#define RETURN_K            "return_key"
#define DATA_JSON           "data"


#define SOCK_NAME           "cwmp_plugin"
#define SOCK_NAME_PUB       "cwmp"


enum ubus_message_id {
	UBUS_MSG_UNDEFINED, 					// 0
	UBUS_MSG_HELLO,						    // 1
	UBUS_MSG_PLUGIN_APPLY_BEGIN,		    // 2
	UBUS_MSG_PLUGIN_APPLY_ERROR,		    // 3
	UBUS_MSG_PLUGIN_APPLY_DONE,				// 4
	UBUS_MSG_SEND_BACK_MQTT, 				// 5
	UBUS_MSG_SEND_BACK_MQTT_2 				// 6
};

typedef struct
{
    int message_id;
    char return_key[1024];
    char *data_json;
} message_t;

int check_error(int return_value, int client_sock, char *msg, bool isExit);
void register_subscriber_name(int client_sock, char* name);
int create_new_unix_connection(char *server_path);
static int set_unix_socket_path(struct sockaddr_un *saddr, const char *path_or_name);
int sending_error(int client_sock, char *error_code);

message_t *new_message(int message_id, char *return_key, char *data_json);
void create_json_from_message(message_t *message, char *msg_string);
void destroy_message(message_t *message);
void print_message(message_t *message);

#endif
#ifndef __GET_INFO_H__
#define __GET_INFO_H__

#ifndef __AK_PACKETED
#define __AK_PACKETED __attribute__((__packed__))
#endif

#include "logger.h"
#include "stdint.h"
#include "stdio.h"
#include <unistd.h>
#include <stdbool.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <jansson.h>

#define MAX_TEMP_HISTORY_RECORDS 300

/******************************************************/
/******************************************************/
/******************************************************/
/**************COMMAND USAGE DEFINE SECTION************/
/******************************************************/
/******************************************************/
/******************************************************/
#if defined AX3000C || defined AX3000CV2
/**************** SYSTEM COMMAND ****************/
#define APPVERSION              "hwp.AX3000C.cwmp."GIT_VERSION
#define GET_INTERFACE_WAN       "ip route show default | grep \"default via\" | awk '/default/ {print $5}'"
#define GET_USER_NAME_PPPOE     "uci get network.wan.username"
#define GET_PASS_PPPOE          "uci get network.wan.password"
#define GET_WAN_MAC				"ifconfig eth0 | grep encap:Ethernet | awk '{print $5}'"
#define GET_CPU_USAGE			"mpstat | awk '$12 ~ /[0-9.]+/ { print 100 - $12 }'"
#define UBUS_SYSTEM_INFO 		"ubus call system info"new_all_clients_info
#define GET_PPPOE_WAN_IP		"ifstatus wan | grep '\"address\":' | awk -F'[\"]'  '{print $4}'"

/**************** NETWORK COMMAND ****************/
#define GET_CHANNEL_MODE		"uci get wireless.@wifi-device[%d].channel"
#define GET_HT_MODE				"uci get wireless.@wifi-device[%d].htmode"
#define GET_ENCRYPTION_MODE		"uci get wireless.@wifi-iface[%d].encryption"
#define GET_SSID_NAME			"uci get wireless.@wifi-iface[%d].ssid"
#define GET_SSID_PASS			"uci get wireless.@wifi-iface[%d].key"
#define GET_INTERFACE_DISABLED	"uci get wireless.@wifi-device[%d].disabled"

/**************** INTERFACE STAT COMMAND ****************/
#define GET_2G_STAT 			"ubus call network.device status '{\"name\":\"ath0\"}'"
#define GET_5G_STAT 			"ubus call network.device status '{\"name\":\"ath1\"}'"
#define GET_LAN_STAT 			"ubus call network.device status '{\"name\":\"eth1\"}'"

/**************** CLIENT STAT COMMAND ****************/
#define GET_CLIENT_STAT_WIFI_2G	"ubus call iwinfo assoclist '{\"device\":\"ath0\"}'"
#define GET_CLIENT_STAT_WIFI_5G	"ubus call iwinfo assoclist '{\"device\":\"ath1\"}'"
#define GET_BASIC_INFO_TOPO		"ubus call network topology"
#define GET_ADV_INFO_TOPO		"ubus call data_repo.data_element get | jsonfilter -e '@.data[0][\"wfa-dataelements:Network\"].DeviceList.*.RadioList.*.BSSList.*.STAList[*][\"MACAddress\",\"SignalStrength\",\"LastDataDownlinkRate\",\"LastDataUplinkRate\",\"BytesSent\",\"BytesReceived\"]' | awk '{printf \"%%s%%s\", toupper($0), (NR%%6 ? \",\" : \"\\n\")}' | grep %s"
#define GET_MESH_ROLE			"ubus call network.wireless.easymesh get  | grep MeshRole | awk -F'[\"]' '{print $4}'"

/**************** TEMPERATURE COMMAND ****************/
#define GET_TEMPERATURE_BY_SENSOR "ubus call  data_repo.device_info.temperature getTemperatureHistory '{\"name\":\"%s\",\"limit\":300}'"
#endif

#if defined LOCAL
/**************** SYSTEM COMMAND ****************/
#define GET_INTERFACE_WAN       "cat unit_test_data.unit | grep interfacewan | awk '{print $2}'"
#define GET_USER_NAME_PPPOE     "cat unit_test_data.unit | grep username | awk '{print $2}'"
#define GET_PASS_PPPOE          "cat unit_test_data.unit | grep password | awk '{print $2}'"
#define GET_WAN_MAC				"cat unit_test_data.unit | grep wanmac | awk '{print $2}'"
#define GET_CPU_USAGE			"cat unit_test_data.unit | grep cpuusage | awk '{print $2}'"
#define UBUS_SYSTEM_INFO 		"cat systeminfo.unit"
#define UBUS_BOARD_INFO			"cat systemboard.unit"
#define GET_SERIAL_NUMBER		"cat unit_test_data.unit | grep serialnummber | awk '{print $2}'"

/**************** NETWORK COMMAND ****************/
#define GET_CHANNEL_MODE		"cat unit_test_data.unit | grep channel%d | awk '{print $2}'"
#define GET_HT_MODE				"cat unit_test_data.unit | grep ht%d | awk '{print $2}'"
#define GET_ENCRYPTION_MODE		"cat unit_test_data.unit | grep encryption%d | awk '{print $2}'"
#define GET_SSID_NAME			"cat unit_test_data.unit | grep ssid%d | awk '{print $2}'"
#define GET_SSID_PASS			"cat unit_test_data.unit | grep pass%d | awk '{print $2}'"
#define GET_INTERFACE_DISABLED	"cat unit_test_data.unit | grep disabled%d | awk '{print $2}'"
#define GET_PPPOE_WAN_IP		"cat unit_test_data.unit | grep pppoeipwan | awk '{print $2}'"

/**************** INTERFACE STAT COMMAND ****************/
#define GET_2G_STAT 			"cat 2g_stat.unit"
#define GET_5G_STAT 			"cat 5g_stat.unit"
#define GET_LAN_STAT 			"cat 5g_stat.unit"
#define GET_CLIENT_STAT_WIFI_2G	"cat 2g_client.unit"
#define GET_CLIENT_STAT_WIFI_5G	"cat 5g_client.unit"
#define WGET_WITH_DEST			"wget -q %s -O %s"
#define GET_FREE_MEM			"df | grep \"/tmp\" | grep -v \"root\" | awk '{print $4}'"
#define SYNC_DROP_CACHES		"sync && echo 3 > /proc/sys/vm/drop_caches"
#define GET_TEMPERATURE_BY_SENSOR "ubus call  data_repo.device_info.temperature getTemperatureHistory '{\"name\":\"%s\",\"limit\":300}'"
#define GET_BASIC_INFO_TOPO		"cat topology.unit"
#define GET_ADV_INFO_TOPO		"ubus call data_repo.data_element get"
#endif

/******************************************************/
/******************************************************/
/******************************************************/
/**************CONSTANT DEFINE SECTION*****************/
/******************************************************/
/******************************************************/
/******************************************************/

/**************** WAN MODE SECTION ****************/
#define BRIDGE_WAN_INTERFACE    "br-lan"		// default interface wan in bridge mode.
#define PPPOE_WAN_INTERFACE     "pppoe-wan"		// default interface wan in PPPoE mode.
#define DHCP_WAN_INTERFACE      "eth0"			// default interface wan in DHCP mode or Ip static mode.

// wan_mode: work mode index setting for AX3000, AX3000CV2.
enum wan_mode {
	WAN_MODE_PPPOE = 0,
	WAN_MODE_BRIDGE,
	WAN_MODE_DHCP,

    MAX_WAN_MODE
};

// wan_dictionary: convert wan mode index into string name
static char wan_dictionary[MAX_WAN_MODE][10] = {"PPPoE", "Bridge", "DHCP"};

/**************** INTERFACE MODE SECTION ****************/
// interface_index: for interface statistic, split into 3 interface: wifi 2Ghz, wifi 5Ghz and LAN.
enum interface_index {
	WIFI_2_INDEX = 0,
	WIFI_5_INDEX,
	LAN_INDEX,

	MAX_INTERFACE_INDEX
};

/******************************************************/
/******************************************************/
/******************************************************/
/**************STRUCT DEFINE SECTION*****************/
/******************************************************/
/******************************************************/
/******************************************************/

// system_info_t: struct for storage system info of CPE
typedef struct {
	int mesh_mode;
	int wan_mode;
	float cpu_usage;
	long long usage_memory;
	long long total_memory;
	int uptime;
	int temperature;
	char reboot_reason[100];
	char reboot_subreason[100];
	char kernel_version[20];
	char hostname[100];
	char model_name[100];
	char serial_number[50];
	char wan_mac[20];
	char firmware_version[10];
	char openwrt_version[30];
} __AK_PACKETED system_info_t;

// interface_info_t: general info of wifi interface
typedef struct {
	int wlan_disabled;
	char interface[5];
	char wlan_ht[10];
	char wlan_channel[10];
	char wlan_encryption[20];
	char wlan_ssid[100];
	char wlan_pass[100];
}__AK_PACKETED interface_info_t;

// network_info_t: include 2 interface info: wifi 2.4Ghz and 5Ghz
typedef struct {
	char ip_wan[20];
	interface_info_t interface[2];
} __AK_PACKETED network_info_t;

// interface_stat_t: statistic info of each interface
typedef struct {
	char interface[10];
	long long tx_bytes;
	long long rx_bytes;
	long long tx_errors;
	long long rx_errors;
	long long tx_dropped;
	long long rx_dropped;
	long long tx_packets;
	long long rx_packets;
	long long multicast;
}__AK_PACKETED interface_stat_t;

// all_interface_stat_t: an array to store interface statistic: [WIFI 2GHz, WIFI 5GHz, LAN]
typedef struct {
	interface_stat_t interface[3];
}__AK_PACKETED all_interface_stat_t;

// client_info_t: statistic info of each client
typedef struct {
	char mac_client[20];
	char parrent_device[100];
	char band[10];
	char hostname[100];

	//connection info
	int signal;
	int signal_avg;
	int connected_time;

	
	// usage info
	long long rx_bytes;
	long long rx_packets;
	long long rx_bw;
	int rx_rate;
	int rx_mcs;
	bool rx_ht;
	bool rx_vht;
	bool rx_he;
	bool rx_short_gi;

	long long tx_bytes;
	long long tx_packets;
	long long tx_bw;
	long long tx_failed;
	long long tx_retries;
	int tx_rate;
	int tx_mcs;
	bool tx_ht; //wifi 4
	bool tx_vht; //wifi 5
	bool tx_he; //wifi 6
	bool tx_short_gi;
}__AK_PACKETED client_info_t;

// all_client_info_t: statistic info of all clients in LAN
typedef struct {
	client_info_t* clients;
	int list_len;
	char self_serial_number[100];
}__AK_PACKETED all_client_info_t;

// temperature_element_t: data struct of one time point
typedef struct {
	char sensor_name[20];
	long long timestamp[MAX_TEMP_HISTORY_RECORDS];
	int temperature[MAX_TEMP_HISTORY_RECORDS];
	int list_len;
}__AK_PACKETED sensor_history_t;

// sensor_history_t: all history of one sensor
typedef struct {
	sensor_history_t sensors[4];
}__AK_PACKETED all_sensor_history_t;


// client_connection_info_t: data of one client
typedef struct {
	char interface_mac[20];
	char interface_name[20];
	char client_mac[20];
	char client_ip[20];
	char client_hostname[100];
	int signal;
	int rx_rate;
	int tx_rate;
	long long tx_byte;
	long long rx_byte;
}__AK_PACKETED client_connection_info_t;

// cpe_clients_list_t: data of one cpe with maximum 100 clients
typedef struct {
	char ip[20];
	char hostname[100];
	char mesh_role[11];
	char parent_node[20];
	char self_mac[20];
	int total_clients;
	client_connection_info_t clients[100];
}__AK_PACKETED cpe_clients_list_t;

// network_topology_t: data of topology include controller and maximun 20 agents
typedef struct {
	cpe_clients_list_t controller;
	cpe_clients_list_t agents[20];
	int total_agent;
}__AK_PACKETED network_topology_t;

/******************************************************/
/******************************************************/
/******************************************************/
/**************FUNCTION DEFINE SECTION*****************/
/******************************************************/
/******************************************************/
/******************************************************/

/**************** SYSTEMINFO SECTION ****************/
int 			get_wan_index();
int 			get_pppoe_account(int mode, char* user, char* password);
void 			get_wan_mac(char* mac);

int 			get_system_info(system_info_t* system_info);
void 			destroy_system_info(system_info_t* system_info);
system_info_t* 	new_system_info();
void 			printf_system_struct(system_info_t *system_info);

/**************** NETWORK SECTION ****************/
int			 		get_ip_wan(char* ip, int wan_mode);
network_info_t* 	new_network_info();
void 				destroy_network_info(network_info_t* network_info);
void 				get_all_network_info(network_info_t* network_info);
int 				get_wan_index();
/**************** INTERFACE SECTION ****************/
all_interface_stat_t* 	new_all_interface_stat();
void 					destroy_all_interface_stat(all_interface_stat_t* a);
int 					get_all_interface_stat(all_interface_stat_t* a);

/**************** CLIENT SECTION ****************/
all_client_info_t* 	new_all_clients_info();
void 				destroy_all_client_info(all_client_info_t* all_client_info);
int 				get_clients_with_interface(all_client_info_t* all_client_info, int interface_index);
int 				get_all_client_info(all_client_info_t* all_client_info);
void 				printf_all_clients_info(all_client_info_t* all_client_info);

/**************** TEEMPERATURE SECTION ****************/
all_sensor_history_t* 	new_sensors_history();
void 					destroy_all_sensor_history(all_sensor_history_t* sensors);
int 					get_all_sensors_history(all_sensor_history_t* sensor_history);

/**************** TOPOLOGY SECTION ****************/
int 					get_full_topology(network_topology_t* topo);
network_topology_t* 	new_topology();
void 					destroy_network_topology(network_topology_t* topo);
int 					get_mesh_role();
#endif
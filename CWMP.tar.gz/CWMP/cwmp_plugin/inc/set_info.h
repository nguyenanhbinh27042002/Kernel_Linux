#ifndef __GET_INFO_H__
#define __GET_INFO_H__

#include <sys/reboot.h>
#include <unistd.h>
#include <stdio.h>

#define FIRMWARE_STORAGE_DEST   "/tmp/%s"

/**************** UTILS COMMAND ****************/
#define WGET_WITH_DEST			"wget -q %s -O %s; echo \"file_name %s\" > /tmp/firmware_upgrade.conf;"
#define GET_FREE_MEM			"df | grep \"/tmp\" | grep -v \"root\" | awk '{print $4}'"
#define SYNC_DROP_CACHES		"sync && echo 3 > /proc/sys/vm/drop_caches"
#define SYSUPGRADE              "sysupgrade %s > /dev/null 2>&1"
#define GET_FIRMWARE_PATH       "cat /tmp/firmware_upgrade.conf | grep file_name | awk '{print $2}'"

int exec_reboot_action();
int exec_download_file_action(char* url, char* save_dest);
int exec_sysupgrade_action();
#endif
#ifndef __UNIX_SOCKET_TASK_H__
#define __UNIX_SOCKET_TASK_H__

#include "ak/ak.h"
#include "task_list.h"

extern void *task_app_unix_socket_entry(void);
extern q_msg_t gw_task_app_unix_socket_mailbox;
#endif
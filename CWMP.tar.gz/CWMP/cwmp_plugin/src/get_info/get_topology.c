#include "get_info.h"
#include "rc_code.h"
#include "utils.h"
#include "logger.h"

#define     CONTROLLER      0
#define     AGENT           1


int get_mesh_role();
void print_topoly(network_topology_t* topo);
int get_basic_agent_topology(network_topology_t* topo);
int get_basic_controller_topology(network_topology_t* topo);
void get_client_data_by_mac(client_connection_info_t* client);
int get_advance_client_info(network_topology_t* topo);

network_topology_t* new_topology() {
    network_topology_t* topo = (network_topology_t*)malloc(sizeof(network_topology_t));
    topo->total_agent = 0;
    return topo;
}

void destroy_network_topology(network_topology_t* topo) {
    if(topo) {
        free(topo);
        topo = NULL;
    }
}

void init_new_agent(network_topology_t* topo, char* parent_node) {
    int index = topo->total_agent;
    topo->agents[index].total_clients = 0;
    memset(topo->agents[index].mesh_role, '\0', 11);
    memset(topo->agents[index].parent_node, '\0', 20);
    memset(topo->agents[index].ip, '\0', 20);
    memset(topo->agents[index].hostname, '\0', 100);
    memset(topo->agents[index].self_mac, '\0', 20);


    strcpy(topo->agents[index].mesh_role, "agent");
    strcpy(topo->agents[index].parent_node, parent_node);
}

void init_new_controller(network_topology_t* topo) {
    topo->controller.total_clients = 0;
    memset(topo->controller.mesh_role, '\0', 11);
    memset(topo->controller.parent_node, '\0', 20);
    memset(topo->controller.ip, '\0', 20);
    memset(topo->controller.hostname, '\0', 100);
    memset(topo->controller.self_mac, '\0', 20);

    strcpy(topo->controller.mesh_role, "controller");
    strcpy(topo->controller.parent_node, "root");
}

void create_new_client(cpe_clients_list_t* cpe, char* interface_mac,
    char* interface_name, char* client_mac, char* client_ip, char* client_hostname) {

    int index = cpe->total_clients;
    memset(cpe->clients[index].interface_mac, '\0', 20);
    memset(cpe->clients[index].interface_name, '\0', 20);
    memset(cpe->clients[index].client_mac, '\0', 20);
    memset(cpe->clients[index].client_ip, '\0', 20);
    memset(cpe->clients[index].client_hostname, '\0', 100);

    strcpy(cpe->clients[index].interface_mac, interface_mac);
    strcpy(cpe->clients[index].interface_name, interface_name);
    strcpy(cpe->clients[index].client_mac, client_mac);
    strcpy(cpe->clients[index].client_ip, client_ip);

    cpe->clients[index].signal = -1;
    cpe->clients[index].rx_rate = -1;
    cpe->clients[index].tx_rate = -1;
    cpe->clients[index].tx_byte = -1;
    cpe->clients[index].rx_byte = -1;

    int hostname_length = strlen(client_hostname);

    if (hostname_length > 99) {
        hostname_length = 99;
    } else {
        hostname_length = hostname_length + 1;
    }

    strncpy(cpe->clients[index].client_hostname, client_hostname, hostname_length);
    cpe->total_clients += 1;
}

int get_full_topology(network_topology_t* topo) {
    int mode = get_mesh_role();
    if (mode == CONTROLLER) {
        get_basic_controller_topology(topo);
        get_advance_client_info(topo);
        return RC_SUCCESS;
    } else {
        return RC_AGENT_NOT_SUPPORT;
    }
}

int get_advance_client_info(network_topology_t* topo) {
    int counter = 0;
    for (counter; counter < topo->controller.total_clients; counter ++ ) {
        get_client_data_by_mac(&(topo->controller.clients[counter]));
        DEBUG("signal: %d", topo->controller.clients[counter].signal);
        DEBUG("tx_byte: %lld", topo->controller.clients[counter].tx_byte);
        DEBUG("tx_rate:  %lld", topo->controller.clients[counter].tx_rate);
        DEBUG("rx_byte:  %lld", topo->controller.clients[counter].rx_byte);
        DEBUG("rx_rate:  %lld", topo->controller.clients[counter].rx_rate);
    }

    int agent_counter = 0;
    for (agent_counter; agent_counter < topo->total_agent; agent_counter ++) {
        int counter = 0;
        for (counter; counter < topo->agents[agent_counter].total_clients; counter ++ ) {
            get_client_data_by_mac(&(topo->agents[agent_counter].clients[counter]));
            DEBUG("signal: %d", topo->agents[agent_counter].clients[counter].signal);
            DEBUG("tx_byte:  %lld", topo->agents[agent_counter].clients[counter].tx_byte);
            DEBUG("tx_rate:  %lld", topo->agents[agent_counter].clients[counter].tx_rate);
            DEBUG("rx_byte:  %lld", topo->agents[agent_counter].clients[counter].rx_byte);
            DEBUG("rx_rate:  %lld", topo->agents[agent_counter].clients[counter].rx_rate);
        }
    }
}

void get_client_data_by_mac(client_connection_info_t* client) {
    char command[512];
    memset(command, '\0', 512);
    sprintf(command, GET_ADV_INFO_TOPO, client->client_mac);
    char data[100];
    memset(data, '\0', 100);

    execute_command_pointer(command, data);
    if (strlen(data) == 0) {
        return ;
    }
    DEBUG("data: %s", data);
    int signal = 0, rx_rate = 0, tx_rate =0;
    long long tx_byte = 0, rx_byte = 0;
    sscanf(data, "%*[^,],%d,%d,%d,%lld,%lld", &client->signal, &client->rx_rate, &client->tx_rate, &client->tx_byte, &client->rx_byte);
}

int get_basic_controller_topology(network_topology_t* topo) {
    char* payload = execute_command_ubus(GET_BASIC_INFO_TOPO);
    json_t* root;
    json_error_t error;

    root = json_loads(payload, 0, &error);
    if (!root) {
        free(payload);
        printf("ERROR! json load string failed with err: %s", error);
        return RC_JSON_ERROR;
    }

    const char *key;
    json_t *value;
    json_object_foreach(root, key, value) {

        json_t* interface_info = json_object();
        json_t* info_obj = json_object_get(value, "info");
        const char *key_info;
        json_t *value_info;
        json_object_foreach(info_obj, key_info, value_info) {
            char* medium_type = (char*)json_string_value(json_object_get(value_info, "medium_type"));
            json_object_set_new(interface_info, (char*)json_string_value(json_object_get(value_info, "mac")), json_string(medium_type));
        }

        json_t* backhaul =  json_object_get(value, "backhaul");
        if (backhaul == NULL) {
            init_new_controller(topo);
            
            char* ip = (char*)json_string_value(json_object_get(value, "ip"));
            char* hostname =  (char*)json_string_value(json_object_get(value, "hostname"));
            if (ip != NULL) {
                strcpy(topo->controller.ip, ip);
            }

            if (key != NULL) {
                strcpy(topo->controller.self_mac, key);
            }

            int hostname_length = strlen(hostname);
            if (hostname_length > 99) {
                hostname_length = 99;
            } else {
                hostname_length = hostname_length + 1;
            }
            strncpy(topo->controller.hostname, hostname, hostname_length);

            json_t* legacy_devices = json_object_get(value, "legacy_devices");
            size_t index;
            json_t *elements;
            json_array_foreach(legacy_devices, index, elements)
            {
                char* interface_mac = (char*)json_string_value(json_object_get(elements, "connect_interface"));
                char* interface_name = (char*)json_string_value(json_object_get(interface_info, interface_mac));
                char* client_mac = (char*)json_string_value(json_object_get(elements, "mac"));
                char* client_ip = (char*)json_string_value(json_object_get(elements, "ip"));
                char* client_hostname = (char*)json_string_value(json_object_get(elements, "hostname"));

                create_new_client(&(topo->controller), interface_mac, interface_name, client_mac, client_ip, client_hostname);
            }
        } else {
            char* mac_controller = (char*)json_string_value(json_object_get(backhaul, "mac"));
            init_new_agent(topo, mac_controller);
            int index = topo->total_agent;
            char* ip = (char*)json_string_value(json_object_get(value, "ip"));
            char* hostname =  (char*)json_string_value(json_object_get(value, "hostname"));

            if (ip != NULL) {
                strcpy(topo->agents[index].ip, ip);
            }

            if (key != NULL) {
                strcpy(topo->agents[index].self_mac, key);
            }


            int hostname_length = strlen(hostname);
            if (hostname_length > 99) {
                hostname_length = 99;
            } else {
                hostname_length = hostname_length + 1;
            }
            strncpy(topo->agents[index].hostname, hostname, hostname_length);
            json_t* legacy_devices = json_object_get(value, "legacy_devices");
            size_t index_legacy;
            json_t *elements;
            json_array_foreach(legacy_devices, index_legacy, elements)
            {
                char* interface_mac = (char*)json_string_value(json_object_get(elements, "connect_interface"));
                char* interface_name = (char*)json_string_value(json_object_get(interface_info, interface_mac));
                char* client_mac = (char*)json_string_value(json_object_get(elements, "mac"));
                char* client_ip = (char*)json_string_value(json_object_get(elements, "ip"));
                char* client_hostname = (char*)json_string_value(json_object_get(elements, "hostname"));

                create_new_client(&(topo->agents[index]), interface_mac, interface_name, client_mac, client_ip, client_hostname);
            }
            topo->total_agent += 1;
        }
        json_decref(interface_info);
    }
    free(payload);
    json_decref(root);
    return RC_SUCCESS;
}

int get_basic_agent_topology(network_topology_t* topo) {
    DEBUG("1");
    char* payload = execute_command_ubus(GET_BASIC_INFO_TOPO);
    json_t* root;
    json_error_t error;

    root = json_loads(payload, 0, &error);
    if (!root) {
        free(payload);
        printf("ERROR! json load string failed with err: %s", error);
        return RC_JSON_ERROR;
    }
    DEBUG("1");

    const char *key;
    json_t *value;
    json_object_foreach(root, key, value) {

        json_t* interface_info = json_object();
        json_t* info_obj = json_object_get(value, "info");
        const char *key_info;
        json_t *value_info;
        json_object_foreach(info_obj, key_info, value_info) {
            char* medium_type = (char*)json_string_value(json_object_get(value_info, "medium_type"));
            json_object_set_new(interface_info, (char*)json_string_value(json_object_get(value_info, "mac")), json_string(medium_type));
        }
        DEBUG("1");

        json_t* backhaul =  json_object_get(value, "backhaul");
        if (backhaul != NULL) {
            init_new_controller(topo);
            
            char* ip = (char*)json_string_value(json_object_get(value, "ip"));
            if (ip != NULL) {
                strcpy(topo->controller.ip, ip);
            }

            if (key != NULL) {
                strcpy(topo->controller.self_mac, key);
            }
        DEBUG("1");
            
            json_t* legacy_devices = json_object_get(value, "legacy_devices");
            size_t index;
            json_t *elements;
            json_array_foreach(legacy_devices, index, elements)
            {
                char* interface_mac = (char*)json_string_value(json_object_get(elements, "connect_interface"));
                char* interface_name = (char*)json_string_value(json_object_get(interface_info, interface_mac));
                char* client_mac = (char*)json_string_value(json_object_get(elements, "mac"));

                create_new_client(&(topo->controller), interface_mac, interface_name, client_mac, "n/a", "n/a");
            }
        } else {
    DEBUG("1");

            char* mac_controller = (char*)json_string_value(json_object_get(backhaul, "mac"));
            init_new_agent(topo, mac_controller);
              DEBUG("1");
            int index = topo->total_agent;
            char* ip = (char*)json_string_value(json_object_get(value, "ip"));

            if (ip != NULL) {
                strcpy(topo->agents[index].ip, ip);
            }

            if (key != NULL) {
                strcpy(topo->agents[index].self_mac, key);
            }
    DEBUG("1");
            json_t* legacy_devices = json_object_get(value, "legacy_devices");
            size_t index_legacy;
            json_t *elements;
                DEBUG("1");
            json_array_foreach(legacy_devices, index_legacy, elements)
            {
                char* interface_mac = (char*)json_string_value(json_object_get(elements, "connect_interface"));
                char* interface_name = (char*)json_string_value(json_object_get(interface_info, interface_mac));
                char* client_mac = (char*)json_string_value(json_object_get(elements, "mac"));

                create_new_client(&(topo->agents[index]), interface_mac, interface_name, client_mac, "n/a", "n/a");
            }
                DEBUG("1");
            topo->total_agent += 1;
        }
            DEBUG("1");
        json_decref(interface_info);
    }
    DEBUG("1");

    free(payload);
    json_decref(root);
    DEBUG("1");

    return RC_SUCCESS;
}

void print_topoly(network_topology_t* topo) {
    DEBUG("get_basic_topology");

    DEBUG("Total Agents: %d", topo->total_agent);
    DEBUG("*************************");
    DEBUG("Controller IP: %s", topo->controller.ip);
    DEBUG("Controller Hostname: %s", topo->controller.hostname);
    DEBUG("Controller Mesh Role: %s", topo->controller.mesh_role);
    DEBUG("Controller Parent Node: %s", topo->controller.parent_node);
    DEBUG("Controller Self Mac: %s", topo->controller.self_mac);
    DEBUG("Controller Total Clients: %d", topo->controller.total_clients);
    int counter = 0;
    for (counter; counter < topo->controller.total_clients; counter ++ ) {
        DEBUG("Client ID: %d - Interface mac: %s", counter,  topo->controller.clients[counter].interface_mac);
        DEBUG("Client ID: %d - Interface name: %s", counter,  topo->controller.clients[counter].interface_name);
        DEBUG("Client ID: %d - Client mac: %s", counter,  topo->controller.clients[counter].client_mac);
        DEBUG("Client ID: %d - Client ip: %s", counter,  topo->controller.clients[counter].client_ip);
        DEBUG("Client ID: %d - Client hostname: %s", counter,  topo->controller.clients[counter].client_hostname);
    }

    int agent_counter = 0;
    for (agent_counter; agent_counter < topo->total_agent; agent_counter ++) {
        DEBUG("*************************");
        DEBUG("Agent IP: %s", topo->agents[agent_counter].ip);
        DEBUG("Agent Hostname: %s", topo->agents[agent_counter].hostname);
        DEBUG("Agent Mesh Role: %s", topo->agents[agent_counter].mesh_role);
        DEBUG("Agent Parent Node: %s", topo->agents[agent_counter].parent_node);
        DEBUG("Agent Self Mac: %s", topo->agents[agent_counter].self_mac);
        DEBUG("Agent Total Clients: %d", topo->agents[agent_counter].total_clients);
        int counter = 0;
        for (counter; counter < topo->agents[agent_counter].total_clients; counter ++ ) {
            DEBUG("Client ID: %d - Interface mac: %s", counter,  topo->agents[agent_counter].clients[counter].interface_mac);
            DEBUG("Client ID: %d - Interface name: %s", counter,  topo->agents[agent_counter].clients[counter].interface_name);
            DEBUG("Client ID: %d - Client mac: %s", counter,  topo->agents[agent_counter].clients[counter].client_mac);
            DEBUG("Client ID: %d - Client ip: %s", counter,  topo->agents[agent_counter].clients[counter].client_ip);
            DEBUG("Client ID: %d - Client hostname: %s", counter,  topo->agents[agent_counter].clients[counter].client_hostname);
        }
    }
}


int get_mesh_role() {
    char role[20];
    memset(role, '\0', 20);
    execute_command_pointer(GET_MESH_ROLE, role);
    if (!strcmp(role, "Controller")) {
        return CONTROLLER;
    } else {
        return AGENT;
    }
}
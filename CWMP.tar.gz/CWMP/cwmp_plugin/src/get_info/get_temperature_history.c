#include "get_info.h"
#include "rc_code.h"
#include "utils.h"

all_sensor_history_t* new_sensors_history() {
    all_sensor_history_t* sensor_history = (all_sensor_history_t*)malloc(sizeof(all_sensor_history_t));
    memset(sensor_history->sensors[0].sensor_name, '\0', 20);
    memset(sensor_history->sensors[1].sensor_name, '\0', 20);
    memset(sensor_history->sensors[2].sensor_name, '\0', 20);
    memset(sensor_history->sensors[3].sensor_name, '\0', 20);

    strcpy(sensor_history->sensors[0].sensor_name, "tsens_tz_sensor1");
    strcpy(sensor_history->sensors[1].sensor_name, "tsens_tz_sensor2");
    strcpy(sensor_history->sensors[2].sensor_name, "tsens_tz_sensor3");
    strcpy(sensor_history->sensors[3].sensor_name, "tsens_tz_sensor4");

    memset(sensor_history->sensors[0].timestamp, 0, 300);
    memset(sensor_history->sensors[1].timestamp, 0, 300);
    memset(sensor_history->sensors[2].timestamp, 0, 300);
    memset(sensor_history->sensors[3].timestamp, 0, 300);

    memset(sensor_history->sensors[0].temperature, 0, 300);
    memset(sensor_history->sensors[1].temperature, 0, 300);
    memset(sensor_history->sensors[2].temperature, 0, 300);
    memset(sensor_history->sensors[3].temperature, 0, 300);

    sensor_history->sensors[0].list_len = 0;
    sensor_history->sensors[1].list_len = 0;
    sensor_history->sensors[2].list_len = 0;
    sensor_history->sensors[3].list_len = 0;

    return sensor_history;
}

void destroy_all_sensor_history(all_sensor_history_t* sensors){
    if(sensors) {
        free(sensors);
        sensors = NULL;
    }
}

int sensor_to_index(char* sensor) {
    if (!strcmp(sensor, "tsens_tz_sensor1")) {
        return 0;
    } else if (!strcmp(sensor, "tsens_tz_sensor2")) {
        return 1;
    } else if (!strcmp(sensor, "tsens_tz_sensor3")) {
        return 2;
    } else {
        return 3;
    }
}

int get_sensor_histroy_by_interface(all_sensor_history_t* sensor_history, char* interface) {
    int sensor_index = sensor_to_index(interface);

    char command[100];
    memset(command, '\0', 100);
    sprintf(command, GET_TEMPERATURE_BY_SENSOR, interface);
    
    char* payload = execute_command_ubus(command);
    json_t* root;
    json_error_t error;

    root = json_loads(payload, 0, &error);
    if (!root) {
        free(payload);
        printf("ERROR! json load string failed with err: %s", error);
        return RC_JSON_ERROR;
    }

    json_t* history = json_object_get(root, "history");
    size_t index;
    json_t *value;
    json_array_foreach(history, index, value)
    {
        if (sensor_history->sensors[sensor_index].list_len < MAX_TEMP_HISTORY_RECORDS) {
            int index_arr = sensor_history->sensors[sensor_index].list_len;
            sensor_history->sensors[sensor_index].temperature[index_arr] = (int)json_integer_value(json_object_get(value, "temperature"));
            sensor_history->sensors[sensor_index].timestamp[index_arr] = (long long)json_integer_value(json_object_get(value, "timestamp"));
            sensor_history->sensors[sensor_index].list_len ++;
        }
    }

    free(payload);
    json_decref(root);
    return RC_SUCCESS;
}

int get_all_sensors_history(all_sensor_history_t* sensor_history) {
    int rc = get_sensor_histroy_by_interface(sensor_history, "tsens_tz_sensor1");
    if (rc != RC_SUCCESS) {
        return rc;
    }

    rc = get_sensor_histroy_by_interface(sensor_history, "tsens_tz_sensor2");
    if (rc != RC_SUCCESS) {
        return rc;
    }

    rc = get_sensor_histroy_by_interface(sensor_history, "tsens_tz_sensor3");
    if (rc != RC_SUCCESS) {
        return rc;
    }

    rc = get_sensor_histroy_by_interface(sensor_history, "tsens_tz_sensor4");
    if (rc != RC_SUCCESS) {
        return rc;
    }

    return RC_SUCCESS;
}
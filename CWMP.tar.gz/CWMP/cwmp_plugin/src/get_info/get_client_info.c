#include "get_info.h"
#include "rc_code.h"
#include "utils.h"

all_client_info_t* new_all_clients_info() {
    all_client_info_t* all_client_info = (all_client_info_t*)malloc(sizeof(all_client_info_t));
    all_client_info->list_len = 0;
    memset(all_client_info->self_serial_number, '\0', 100);
    execute_command_pointer(GET_SERIAL_NUMBER, all_client_info->self_serial_number);
    all_client_info->clients = (client_info_t*)malloc(sizeof(client_info_t));
    return all_client_info;
}

// Append a new client to all_client_info_t
void append_client(all_client_info_t* all_clients, client_info_t* new_client) {
    if (all_clients->list_len == 0) {
        memcpy(&(all_clients->clients[0]), new_client, sizeof(client_info_t));
        all_clients->clients[0] =  *new_client;

    } else {
        all_clients->clients = (client_info_t*)realloc(all_clients->clients, (all_clients->list_len + 1) * sizeof(client_info_t));
        memcpy(&(all_clients->clients[all_clients->list_len]), new_client, sizeof(client_info_t));
    }
    all_clients->list_len++;
}

void init_data_new_client(client_info_t* new_client) {
    memset(new_client->mac_client, '\0', 20);
    memset(new_client->parrent_device, '\0', 100);
    memset(new_client->band, '\0', 10);
    memset(new_client->hostname, '\0', 100);

    new_client->rx_ht = false;
    new_client->rx_vht = false;
    new_client->rx_he = false;
    new_client->rx_short_gi = false;


    new_client->tx_ht = false;
    new_client->tx_vht = false;
    new_client->tx_he = false;
    new_client->tx_short_gi = false;

    new_client->signal = 0;
    new_client->signal_avg = 0;
    new_client->connected_time = 0;
    new_client->rx_bytes = 0;
    new_client->rx_packets = 0;
    new_client->rx_bw = 0;
    new_client->rx_rate = 0;
    new_client->rx_mcs = 0;
    new_client->tx_bytes = 0;
    new_client->tx_packets = 0;
    new_client->tx_bw = 0;
    new_client->tx_failed = 0;
    new_client->tx_retries = 0;
    new_client->tx_rate = 0;
    new_client->tx_mcs = 0;
}

int get_index_of_client(all_client_info_t* all_client_info) {
    return (all_client_info->list_len - 1);
}

void destroy_all_client_info(all_client_info_t* all_client_info) {
    if (all_client_info) {
        if (all_client_info->clients) {
            free(all_client_info->clients);
        }
        free(all_client_info);
        all_client_info = NULL;
    }
}

int get_all_client_info(all_client_info_t* all_client_info) {
    int rc = get_clients_with_interface(all_client_info, WIFI_2_INDEX);
    if (rc != 0) {
        return rc;
    }

    rc = get_clients_with_interface(all_client_info, WIFI_5_INDEX);
    if (rc != 0) {
        return rc;
    }
    
    if (all_client_info->list_len == 0) {
        return RC_DATA_EMTPY;
    }
    return RC_SUCCESS;
}

int get_clients_with_interface(all_client_info_t* all_client_info, int interface_index) {
    char* clients_payload;
    if (interface_index  ==  WIFI_2_INDEX) {
        clients_payload = execute_command_ubus(GET_CLIENT_STAT_WIFI_2G);
    } else {
        clients_payload = execute_command_ubus(GET_CLIENT_STAT_WIFI_5G);
    }

    json_t* root;
    json_error_t error;

    root = json_loads(clients_payload, 0, &error);
    if (!root) {
        free(clients_payload);
        printf("ERROR! json load string failed with err: %s", error);
        return RC_JSON_ERROR;
    }
    
    
    json_t* results = json_object_get(root, "results");
    int len = json_array_size(results);
    if (len == 0) {
        json_decref(root);
        free(clients_payload);
        return RC_SUCCESS;
    }

    size_t index;
    json_t *value;
    json_array_foreach(results, index, value)
    {
        json_t* rx_object = json_object_get(value, "rx");
        json_t* tx_object = json_object_get(value, "tx");


        client_info_t new_client;
        init_data_new_client(&new_client);


        // general info
        char* mac_client =  (char*)json_string_value(json_object_get(value, "mac"));
        char* parrent_device =  (char*)json_string_value(json_object_get(value, "parentdev"));
        char* band =  (char*)json_string_value(json_object_get(value, "band"));


        if (mac_client != NULL) {
            strcpy(new_client.mac_client, mac_client);
        }

        if (parrent_device != NULL) {
            strcpy(new_client.parrent_device, parrent_device);
        }

        if (band != NULL) {
            strcpy(new_client.band, band);
        }
        
        //connection info
        new_client.signal = (int)json_integer_value(json_object_get(value, "signal"));
        new_client.signal_avg = (int)json_integer_value(json_object_get(value, "signal_avg"));
        new_client.connected_time = (int)json_integer_value(json_object_get(value, "connected_time"));


        //rx usage info
        new_client.rx_bytes = (long long)json_integer_value(json_object_get(rx_object, "bytes"));
        new_client.rx_packets = (long long)json_integer_value(json_object_get(rx_object, "packets"));
        new_client.rx_bw = (long long)json_integer_value(json_object_get(rx_object, "mhz"));
        new_client.rx_rate = (int)json_integer_value(json_object_get(rx_object, "rate"));
        new_client.rx_mcs = (int)json_integer_value(json_object_get(rx_object, "mcs"));


        new_client.rx_ht = (bool)json_boolean_value(json_object_get(rx_object, "ht"));
        new_client.rx_vht = (bool)json_boolean_value(json_object_get(rx_object, "vht"));
        new_client.rx_he = (bool)json_boolean_value(json_object_get(rx_object, "he"));
        new_client.rx_short_gi = (bool)json_boolean_value(json_object_get(rx_object, "short_gi"));


        //tx usage info
        new_client.tx_bytes = (long long)json_integer_value(json_object_get(tx_object, "bytes"));
        new_client.tx_packets = (long long)json_integer_value(json_object_get(tx_object, "packets"));
        new_client.tx_bw  = (long long)json_integer_value(json_object_get(tx_object, "mhz"));
        new_client.tx_failed = (long long)json_integer_value(json_object_get(tx_object, "failed"));
        new_client.tx_retries = (long long)json_integer_value(json_object_get(tx_object, "retries"));
        new_client.tx_rate = (int)json_integer_value(json_object_get(tx_object, "rate"));
        new_client.tx_mcs = (int)json_integer_value(json_object_get(tx_object, "mcs"));


        new_client.tx_ht = (bool)json_boolean_value(json_object_get(tx_object, "ht"));
        new_client.tx_vht = (bool)json_boolean_value(json_object_get(tx_object, "vht"));
        new_client.tx_he = (bool)json_boolean_value(json_object_get(tx_object, "he"));
        new_client.tx_short_gi = (bool)json_boolean_value(json_object_get(tx_object, "short_gi"));

        append_client(all_client_info, &new_client);
    }

    free(clients_payload);

    json_decref(root);

    return RC_SUCCESS;
}

void printf_all_clients_info(all_client_info_t* all_client_info) {
    int index = 0;
    printf("total client: %d\n", all_client_info->list_len);
    printf("serial number: %s\n", all_client_info->self_serial_number);
    for (index; index <  all_client_info->list_len; index++) {
        printf("mac client: %s\n", all_client_info->clients[index].mac_client);
        printf("parrent_device: %s\n", all_client_info->clients[index].parrent_device);
        printf("band: %s\n", all_client_info->clients[index].band);        
        printf("signal: %d\n", all_client_info->clients[index].signal);
        printf("signal_avg: %d\n", all_client_info->clients[index].signal_avg);
        printf("connected_time: %d\n", all_client_info->clients[index].connected_time);

        printf("rx_bytes: %d\n", all_client_info->clients[index].rx_bytes);
        printf("rx_packets: %d\n", all_client_info->clients[index].rx_packets);
        printf("rx_bw: %d\n", all_client_info->clients[index].rx_bw);
        printf("rx_rate: %d\n", all_client_info->clients[index].rx_rate);
        printf("rx_mcs: %d\n", all_client_info->clients[index].rx_mcs);
        printf("ht: %d\n", all_client_info->clients[index].rx_ht);
        printf("vht: %d\n", all_client_info->clients[index].rx_vht);
        printf("he: %d\n", all_client_info->clients[index].rx_he);
        printf("short_gi: %d\n", all_client_info->clients[index].rx_short_gi);

        printf("tx_bytes: %d\n", all_client_info->clients[index].tx_bytes);
        printf("tx_packets: %d\n", all_client_info->clients[index].tx_packets);
        printf("tx_bw: %d\n", all_client_info->clients[index].tx_bw);
        printf("tx_failed: %d\n", all_client_info->clients[index].tx_failed);
        printf("tx_retries: %d\n", all_client_info->clients[index].tx_retries);
        printf("tx_rate: %d\n", all_client_info->clients[index].tx_rate);
        printf("tx_mcs: %d\n", all_client_info->clients[index].tx_mcs);

        printf("ht: %d\n", all_client_info->clients[index].tx_ht);
        printf("vht: %d\n", all_client_info->clients[index].tx_vht);
        printf("he: %d\n", all_client_info->clients[index].tx_he);
        printf("short_gi: %d\n", all_client_info->clients[index].tx_short_gi);
    }
}
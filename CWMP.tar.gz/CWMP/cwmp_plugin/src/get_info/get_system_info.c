#include "get_info.h"
#include "utils.h"
#include "rc_code.h"

int get_board_info(system_info_t* system_info);

system_info_t* new_system_info() {
    system_info_t* system_info = (system_info_t*)malloc(sizeof(system_info_t));

    system_info->cpu_usage = 0;
    system_info->mesh_mode = 0;
    system_info->wan_mode = 0;
    system_info->usage_memory = 0;
    system_info->total_memory = 0;
    system_info->uptime = 0;
    system_info->temperature = 0;

    memset(system_info->reboot_reason, '\0', 100);
    memset(system_info->reboot_subreason, '\0', 100);
    memset(system_info->kernel_version, '\0', 20);
    memset(system_info->hostname, '\0', 100);
    memset(system_info->model_name, '\0', 100);
    memset(system_info->serial_number, '\0', 50);
    memset(system_info->wan_mac, '\0', 20);
    memset(system_info->firmware_version, '\0', 10);
    memset(system_info->openwrt_version, '\0', 30);

    return system_info;
}

void destroy_system_info(system_info_t* system_info) {
    if (system_info) {
        free(system_info);
    }
}


float get_cpu_usage() {
    char temp[10];
    memset(temp, '\0', 10);
    execute_command_pointer(GET_CPU_USAGE, temp);
    
    float cpu_usage= 0.0;
    sscanf(temp, "%f", &cpu_usage);
    return cpu_usage;
}

int get_system_info(system_info_t* system_info) {
    int rc = get_board_info(system_info);
    if (rc != RC_SUCCESS) {
        return rc;
    }

    char* system_payload = execute_command_ubus(UBUS_SYSTEM_INFO);

    json_t* root;
    json_error_t error;

    root = json_loads(system_payload, 0, &error);
    if (!root) {
        return RC_JSON_ERROR;
    }

    char* reboot_reason = (char*)json_string_value(json_object_get(root, "rebootReason"));
    char* reboot_subreason = (char*)json_string_value(json_object_get(root, "rebootSubReason"));
    int temperature = (int)json_integer_value(json_object_get(root, "temperature"));
    int uptime = (int)json_integer_value(json_object_get(root, "uptime"));


    json_t* memory_obj = json_object_get(root, "memory");

    long long total_memory = (long long)json_integer_value(json_object_get(memory_obj, "total"));
    long long free_memory= (long long)json_integer_value(json_object_get(memory_obj, "free"));
    long long usage_memory = total_memory - free_memory;
    float cpu_usage = get_cpu_usage();

    if(reboot_reason != NULL) {
        strcpy(system_info->reboot_reason, reboot_reason);
    }

    if (reboot_subreason != NULL) {
        strcpy(system_info->reboot_subreason, reboot_subreason);
    }
    
    
    system_info->temperature = temperature;
    system_info->uptime = uptime;
    system_info->usage_memory = usage_memory;
    system_info->total_memory = total_memory;
    system_info->cpu_usage = cpu_usage;
    system_info->mesh_mode = get_mesh_role();
    system_info->wan_mode = get_wan_index();
    free(system_payload);
    json_decref(root);
    return RC_SUCCESS;
}


int get_board_info(system_info_t* system_info) {
    char* board_payload = execute_command_ubus(UBUS_BOARD_INFO);
    json_t* root;
    json_error_t error;

    root = json_loads(board_payload, 0, &error);
    if (!root) {
        return RC_JSON_ERROR;
    }

    char* kernel = (char*)json_string_value(json_object_get(root, "kernel"));
    char* hostname = (char*)json_string_value(json_object_get(root, "hostname"));
    char* model_name = (char*)json_string_value(json_object_get(root, "model_name"));
    char* serial_number = (char*)json_string_value(json_object_get(root, "serial_number"));
    char* wan_mac = (char*)json_string_value(json_object_get(root, "wan_mac"));

    json_t* release = json_object_get(root, "release");
    char* openwrt_version =  (char*)json_string_value(json_object_get(release, "version"));
    char* fw_version =  (char*)json_string_value(json_object_get(release, "revision"));

    if (kernel != NULL) {
        strcpy(system_info->kernel_version, kernel);
    }

    if (hostname != NULL) {
       strcpy(system_info->hostname, hostname);
    }

    if (model_name != NULL) {
        strcpy(system_info->model_name, model_name);
    }

    if (serial_number != NULL) {
        strcpy(system_info->serial_number, serial_number);
    }

    if (wan_mac != NULL) {
        strcpy(system_info->wan_mac, wan_mac);
    }

    if (openwrt_version != NULL) {
        strcpy(system_info->openwrt_version, openwrt_version);
    }

    if (fw_version != NULL) {
        strcpy(system_info->firmware_version, fw_version);
    }

    free(board_payload);
    json_decref(root);
    return 0;
}

void printf_system_struct( system_info_t *system_info) {
    printf("cpu usage: %f\n", system_info->cpu_usage);
    printf("memeory usage: %lld\n", system_info->usage_memory);
    printf("memory total: %lld\n", system_info->total_memory);
    printf("uptime: %d\n", system_info->uptime);
    printf("temporature: %d\n", system_info->temperature);
    printf("reboot reason: %s\n", system_info->reboot_reason);
    printf("reboot sub-reason: %s\n", system_info->reboot_subreason);
    printf("kernel version: %s\n", system_info->kernel_version);
    printf("hostname: %s\n", system_info->hostname);
    printf("model name: %s\n", system_info->model_name);
    printf("serial numer: %s\n", system_info->serial_number);
    printf("WAN mac: %s\n", system_info->wan_mac);
    printf("firmware version: %s\n", system_info->firmware_version);
    printf("openwrt version: %s\n", system_info->openwrt_version);
}
#include "get_info.h"
#include "utils.h"
#include "rc_code.h"

int get_interface_stat(all_interface_stat_t* a, int interface_mode);

all_interface_stat_t* new_all_interface_stat() {
    all_interface_stat_t* a = (all_interface_stat_t*)(malloc(sizeof(all_interface_stat_t)));

    memset(a->interface[LAN_INDEX].interface, '\0', 10);
    memset(a->interface[WIFI_5_INDEX].interface, '\0', 10);
    memset(a->interface[WIFI_2_INDEX].interface, '\0', 10);

    strcpy(a->interface[LAN_INDEX].interface, "LAN");
    strcpy(a->interface[WIFI_5_INDEX].interface, "5Ghz");
    strcpy(a->interface[WIFI_2_INDEX].interface, "2Ghz");

    int index =0;
    for (index; index < MAX_INTERFACE_INDEX; index ++ ) {
        a->interface[index].tx_bytes = 0;
        a->interface[index].rx_bytes = 0;
        a->interface[index].tx_errors = 0;
        a->interface[index].rx_errors = 0;
        a->interface[index].tx_dropped = 0;
        a->interface[index].rx_dropped = 0;
        a->interface[index].tx_packets = 0;
        a->interface[index].rx_packets = 0;
        a->interface[index].multicast = 0;
    }


    return a;
}

void destroy_all_interface_stat(all_interface_stat_t* a) {
    if (a) {
        free(a);
    }
}

int get_all_interface_stat(all_interface_stat_t* a) {
    int rc = 0;
    rc  =  get_interface_stat(a, WIFI_2_INDEX);
    if (rc != RC_SUCCESS ) {
        return rc;
    }

    rc = get_interface_stat(a, WIFI_5_INDEX);
    if (rc != RC_SUCCESS ) {
        return rc;
    }

    rc = get_interface_stat(a, LAN_INDEX);
    if (rc != RC_SUCCESS ) {
        return rc;
    }

    return RC_SUCCESS;
}

int get_interface_stat(all_interface_stat_t* a, int interface_mode) {
    json_t* root;
    json_error_t error;
    if (interface_mode == WIFI_2_INDEX) {
        char *interface_payload = execute_command_ubus(GET_2G_STAT);
        root = json_loads(interface_payload, 0, &error);
        if (!root) {
            return RC_JSON_ERROR;
        }
        free(interface_payload);
    } else if (interface_mode == WIFI_5_INDEX) {
        char *interface_payload = execute_command_ubus(GET_5G_STAT);
        root = json_loads(interface_payload, 0, &error);
        if (!root) {
            return RC_JSON_ERROR;
        }
        free(interface_payload);
    } else {
        char *interface_payload = execute_command_ubus(GET_LAN_STAT);
        root = json_loads(interface_payload, 0, &error);
        if (!root) {
            return RC_JSON_ERROR;
        }
        free(interface_payload);
    }

    json_t* statistics = json_object_get(root, "statistics");
    a->interface[interface_mode].tx_bytes =  (long long)json_integer_value(json_object_get(statistics, "tx_bytes"));
    a->interface[interface_mode].rx_bytes =  (long long)json_integer_value(json_object_get(statistics, "rx_bytes"));
    a->interface[interface_mode].tx_errors = (long long)json_integer_value(json_object_get(statistics, "tx_errors"));
    a->interface[interface_mode].rx_errors = (long long)json_integer_value(json_object_get(statistics, "rx_errors"));
    a->interface[interface_mode].tx_dropped = (long long)json_integer_value(json_object_get(statistics, "tx_dropped"));
    a->interface[interface_mode].rx_dropped = (long long)json_integer_value(json_object_get(statistics, "rx_dropped"));
    a->interface[interface_mode].tx_packets = (long long)json_integer_value(json_object_get(statistics, "tx_packets"));
    a->interface[interface_mode].rx_packets = (long long)json_integer_value(json_object_get(statistics, "rx_packets"));
    a->interface[interface_mode].multicast =  (long long)json_integer_value(json_object_get(statistics, "multicast"));

    
    json_decref(root);
    return RC_SUCCESS;
}
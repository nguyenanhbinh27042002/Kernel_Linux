#include "get_info.h"
#include "utils.h" 
#include "rc_code.h"

#define MAXLINE 200

int stun_xor_addr(char *stun_server_ip, short stun_server_port, char *return_ip_port);
int get_dns_stun(char *ip);
int get_ip_wan_ap_mode(char* ip_wan);
int get_ip_wan_pppoe_mode(char* ip);
void get_network_info(network_info_t* network_info, int wifi_index) ;

network_info_t* new_network_info() {
    network_info_t* network_info = (network_info_t*)malloc(sizeof(network_info_t));

    network_info->interface[0].wlan_disabled = 0;
    network_info->interface[1].wlan_disabled = 0;

    memset(network_info->ip_wan, '\0', 20);
    memset(network_info->interface[0].interface, '\0', 5);
    memset(network_info->interface[0].wlan_ht, '\0', 10);
    memset(network_info->interface[0].wlan_channel, '\0', 10);
    memset(network_info->interface[0].wlan_encryption, '\0', 20);
    memset(network_info->interface[0].wlan_ssid, '\0', 100);
    memset(network_info->interface[0].wlan_pass, '\0', 100);

    memset(network_info->interface[1].interface, '\0', 5);
    memset(network_info->interface[1].wlan_ht, '\0', 10);
    memset(network_info->interface[1].wlan_channel, '\0', 10);
    memset(network_info->interface[1].wlan_encryption, '\0', 20);
    memset(network_info->interface[1].wlan_ssid, '\0', 100);
    memset(network_info->interface[1].wlan_pass, '\0', 100);

    strcpy(network_info->interface[0].interface, "2Ghz");
    strcpy(network_info->interface[1].interface, "5Ghz");
    return network_info;
}

void destroy_network_info(network_info_t* network_info) {
    if (network_info) {
        free(network_info);
    }
}

void get_all_network  _info(network_info_t* network_info) {
    get_network_info(network_info, WIFI_2_INDEX);
    get_network_info(network_info, WIFI_5_INDEX);
}

void get_network_info(network_info_t* network_info, int wifi_index) {
    char cmd[100];
    char tmp[5];
    memset(tmp, '\0', 5);

    memset(cmd, '\0', 100);
    sprintf(cmd, GET_CHANNEL_MODE, wifi_index);
    execute_command_pointer(cmd, network_info->interface[wifi_index].wlan_channel);

    memset(cmd, '\0', 100);
    sprintf(cmd, GET_HT_MODE, wifi_index);
    execute_command_pointer(cmd, network_info->interface[wifi_index].wlan_ht);

    memset(cmd, '\0', 100);
    sprintf(cmd, GET_ENCRYPTION_MODE, wifi_index);
    execute_command_pointer(cmd, network_info->interface[wifi_index].wlan_encryption);

    memset(cmd, '\0', 100);
    sprintf(cmd, GET_SSID_NAME, wifi_index);
    execute_command_pointer(cmd, network_info->interface[wifi_index].wlan_ssid);

    memset(cmd, '\0', 100);
    sprintf(cmd, GET_SSID_PASS, wifi_index);
    execute_command_pointer(cmd, network_info->interface[wifi_index].wlan_pass);

    memset(cmd, '\0', 100);
    sprintf(cmd, GET_INTERFACE_DISABLED, wifi_index);
    execute_command_pointer(cmd, tmp);

    sscanf(tmp, "%d", &(network_info->interface[wifi_index].wlan_disabled));
    int wan_mode = get_wan_index();
    get_ip_wan(network_info->ip_wan,wan_mode);
}

void get_wan_mac(char* mac) {
    char* mac_ptr = mac;
    execute_command_pointer(GET_WAN_MAC, mac_ptr);
}

int get_wan_index() {
    char temp[10];
    memset(temp, '\0', 10);
    execute_command_pointer(GET_INTERFACE_WAN, temp);
    if (!strcmp(BRIDGE_WAN_INTERFACE, temp)) {
        return WAN_MODE_BRIDGE;
    } else if (!strcmp(PPPOE_WAN_INTERFACE, temp)) {
        return WAN_MODE_PPPOE;
    } else if (!strcmp(DHCP_WAN_INTERFACE, temp)) {
        return WAN_MODE_DHCP;
    } else {
        return MAX_WAN_MODE;
    }
}

int get_pppoe_account(int mode, char* user, char* password) {
    if (mode != WAN_MODE_PPPOE) {
        return RC_ACTION_NOT_IMPLEMENT;
    }

    char* user_ptr = user;
    char* pass_ptr = password;

    execute_command_pointer(GET_USER_NAME_PPPOE, user_ptr);
    execute_command_pointer(GET_PASS_PPPOE, pass_ptr);
    return 0;
}

int get_ip_wan(char* ip, int wan_mode) {
    if (wan_mode == WAN_MODE_PPPOE) {
        int rc = get_ip_wan_pppoe_mode(ip);
        return rc;
    } else if (wan_mode == WAN_MODE_BRIDGE || wan_mode == WAN_MODE_DHCP) {
        int rc = get_ip_wan_ap_mode(ip);
        DEBUG("rc: %d", rc);
        return rc;
    } else {
        return RC_ACTION_NOT_IMPLEMENT;
    }
}

int get_ip_wan_pppoe_mode(char* ip) {
    execute_command_pointer(GET_PPPOE_WAN_IP, ip);
    return 0;
}

int get_ip_wan_ap_mode(char* ip_wan) {
    char ip[20];
    int rc = get_dns_stun(ip);
    if (rc != RC_SUCCESS) {
      return rc;
    }

    int n = 0;
    char return_ip_port[50];
    rc = stun_xor_addr(ip, 2222, return_ip_port);
    if (rc != RC_SUCCESS) {
      return rc;
    }
    sscanf(return_ip_port, "%[^:]%*[:]", ip_wan);
    return RC_SUCCESS;
}

int stun_xor_addr(char *stun_server_ip, short stun_server_port, char *return_ip_port)
{
  struct sockaddr_in servaddr;
  struct sockaddr_in localaddr;
  unsigned char buf[MAXLINE];
  int sockfd, i;
  unsigned char bindingReq[20];

  int stun_method, msg_length;
  short attr_type;
  short attr_length;
  short port;
  short n;

  sockfd = socket(AF_INET, SOCK_DGRAM, 0); // UDP

  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  inet_pton(AF_INET, stun_server_ip, &servaddr.sin_addr);
  servaddr.sin_port = htons(stun_server_port);

  struct timeval tv;
	tv.tv_sec = 1;
	tv.tv_usec = 0;
	if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
		close(sockfd);
	    return RC_SOCKET_ERROR;
	}

  bzero(&localaddr, sizeof(localaddr));
  localaddr.sin_family = AF_INET;
  n = bind(sockfd, (struct sockaddr *)&localaddr, sizeof(localaddr));

  *(short *)(&bindingReq[0]) = htons(0x0001);   // stun_method
  *(short *)(&bindingReq[2]) = htons(0x0000);   // msg_length
  *(int *)(&bindingReq[4]) = htonl(0x2112A442); // magic cookie

  *(int *)(&bindingReq[8]) = htonl(0x63c7117e); // transacation ID
  *(int *)(&bindingReq[12]) = htonl(0x0714278f);
  *(int *)(&bindingReq[16]) = htonl(0x5ded3221);

  n = sendto(sockfd, bindingReq, sizeof(bindingReq), 0, (struct sockaddr *)&servaddr, sizeof(servaddr)); // send UDP
  if (n == -1)
  {
    printf("sendto error\n");
    return RC_SOCKET_ERROR;
  }

  n = recvfrom(sockfd, buf, MAXLINE, 0, NULL, 0); // recv UDP
  if (n == -1)
  {
    printf("recvfrom error\n");
    return RC_SOCKET_ERROR;
  }

  if (*(short *)(&buf[0]) == htons(0x0101))
  {
    // parse XOR
    n = htons(*(short *)(&buf[2]));
    i = 20;
    while (i < sizeof(buf))
    {
      attr_type = htons(*(short *)(&buf[i]));
      attr_length = htons(*(short *)(&buf[i + 2]));
      if (attr_type == 0x0020)
      {
        port = ntohs(*(short *)(&buf[i + 6]));
        port ^= 0x2112;

        sprintf(return_ip_port, "%d.%d.%d.%d:%d", buf[i + 8] ^ 0x21, buf[i + 9] ^ 0x12, buf[i + 10] ^ 0xA4, buf[i + 11] ^ 0x42, port);

        break;
      }
      i += (4 + attr_length);
    }
  }
  close(sockfd);
  return 0;
}

int get_dns_stun(char *ip)
{
  char *ip_pointer = ip;
  struct addrinfo hints;
  struct addrinfo *res;
  struct addrinfo *res0;
  int error;
  char host[NI_MAXHOST];

  memset(&hints, 0, sizeof hints);
  hints.ai_family = PF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;

  error = getaddrinfo("cpestun.fpt.vn", NULL, &hints, &res0);

  if (error)
  {
    fprintf(stderr, "get dns %s\n", gai_strerror(error));
    return RC_SOCKET_ERROR;
  }

  for (res = res0; res; res = res->ai_next)
  {
    error = getnameinfo(res->ai_addr, res->ai_addrlen,
                        host, sizeof host, NULL, 0, NI_NUMERICHOST);

    if (error)
    {
      fprintf(stderr, "%s\n", gai_strerror(error));
    }
    else
    {
      if (strstr((char *)host, ":") == NULL)
        strcpy(ip_pointer, host);
    }
  }
  /* Free the linked list. */
  freeaddrinfo(res0);
  return RC_SUCCESS;
}


void printf_network_struct(network_info_t* network_info) {
    printf("IPprintf_network_struct WAN: %s\n", network_info->ip_wan);

    printf("interface: %s\n", network_info->interface[0].interface);
    printf("disabled: %d\n", network_info->interface[0].wlan_disabled);
    printf("HT: %s\n", network_info->interface[0].wlan_ht);
    printf("Channel: %s\n", network_info->interface[0].wlan_channel);
    printf("Encryption: %s\n", network_info->interface[0].wlan_encryption);
    printf("Ssid: %s\n", network_info->interface[0].wlan_ssid);
    printf("Pass: %s\n", network_info->interface[0].wlan_pass);

    printf("interface: %s\n", network_info->interface[1].interface);
    printf("disabled: %d", network_info->interface[1].wlan_disabled);
    printf("HT: %s\n", network_info->interface[1].wlan_ht);
    printf("Channel: %s\n", network_info->interface[1].wlan_channel);
    printf("Encryption: %s\n", network_info->interface[1].wlan_encryption);
    printf("Ssid: %s\n", network_info->interface[1].wlan_ssid);
    printf("Pass: %s\n", network_info->interface[1].wlan_pass);
}
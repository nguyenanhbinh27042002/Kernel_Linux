#include "task_list.h"

ak_task_t task_list_init[] = {
    {DEFAULT_AT_FIRST_TASK  , TASK_PRI_LEVEL_1, (void*)timer_entry                  , &timer_mailbox, "timer service"},
    {TASK_APP_UNIX_SOCKET   , TASK_PRI_LEVEL_1, (void*)task_app_unix_socket_entry   , &gw_task_app_unix_socket_mailbox, "unix socket task app"},
    {TASK_APP_SET           , TASK_PRI_LEVEL_1, (void*)task_app_set_entry           , &gw_task_app_set_mailbox, "set task app"},
    {TASK_APP_GET           , TASK_PRI_LEVEL_1, (void*)task_app_get_entry           , &gw_task_app_get_mailbox, "get task app"},
    {TASK_REPLY             , TASK_PRI_LEVEL_1, (void*)task_app_reply_entry         , &gw_task_app_reply_mailbox, "reply task app"},
    {TASK_SELF              , TASK_PRI_LEVEL_1, (void*)task_app_self_entry         , &gw_task_app_self_mailbox, "self task app"},
};
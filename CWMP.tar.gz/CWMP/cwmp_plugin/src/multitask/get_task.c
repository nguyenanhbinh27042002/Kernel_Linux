#include "task_list.h"
#include "json_package.h"
#include "ubus_mapping.h"
#include "ipc.h"

#include <jansson.h>
#include <data_buffer.h>
#include <logger.h>


q_msg_t gw_task_app_get_mailbox;

extern void* task_app_get_entry(void){
    wait_all_tasks_started();
    INFO("Get handler task entry");
    ak_msg_t* msg;
    while(1) {
        msg = ak_msg_rev(TASK_APP_GET);

        char* payload;
        switch (msg->header->sig)
        {
            case GET_SYSTEM_INFO:
                payload = system_info_package_ptr();
                break;

            case GET_INTERFACE_STAT:
                payload = interface_stat_package_ptr();
                break;
                
            case GET_NETWORK_INFO:
                payload = network_info_package_ptr();
                break;

            case GET_CLIENT_INFO:
                payload = clients_json_package_ptr();
                break;

            case GET_TEMP_HISTORY:
                payload = temperature_info_package_ptr();
                break;

            case GET_TOPOLOGY:
                payload = network_topology_package_ptr();
                break;
                
            default:
                break;
        }

        json_error_t error, error_res;
        json_t* root;
        json_t* response_obj;

        root = json_loads(msg->header->payload, 0, &error);
        response_obj = json_loads(payload, 0, &error_res);
        json_object_set_new(root, "data", response_obj);
        json_object_set_new(root, "msg_id", json_integer(UBUS_MSG_SEND_BACK_MQTT_2));


        char* data_str = json_dumps(root, JSON_COMPACT);

		task_post_dynamic_msg(TASK_REPLY, 1, (uint8_t*)data_str, strlen(data_str)+1);

        free(payload);
        free(data_str);
        ak_msg_free(msg);
        json_decref(root);
    }
}
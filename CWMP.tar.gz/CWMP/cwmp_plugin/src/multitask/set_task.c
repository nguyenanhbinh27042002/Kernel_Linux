#include "task_list.h"
#include <logger.h>
#include "ubus_mapping.h"
#include "set_info.h"
#include "ipc.h"
#include <jansson.h>
#include <data_buffer.h>
#include <logger.h>
#include "rc_code.h"
#include "utils.h"

q_msg_t gw_task_app_set_mailbox;

extern void* task_app_set_entry(void){
    wait_all_tasks_started();
    INFO("Set handler task entry");
    ak_msg_t* msg;
    while(1) {
        msg = ak_msg_rev(TASK_APP_SET);
        int rc;
        json_error_t error;
        json_t* root;
        int is_root_loaded =  0;
        int is_silent_return = 0;

        switch (msg->header->sig)
        {
            case SET_REBOOT:
                rc = exec_reboot_action();
                break;

            case DOWNLOAD_FIRMWARE:
                root = json_loads(msg->header->payload, 0, &error);
                is_root_loaded = 1;

                json_t* data = json_object_get(root, "data");
                char* url = (char*)json_string_value(json_object_get(data, "url"));
                char* fw_name = (char*)json_string_value(json_object_get(data, "fw_name"));

                char store_dest[50];
                memset(store_dest, '\0', 50);
                sprintf(store_dest, FIRMWARE_STORAGE_DEST, fw_name);

                rc = exec_download_file_action(url, store_dest);
                if (rc == RC_SUCCESS) {
                    timer_set(TASK_APP_SET, UPGRADE_FIRMWARE, 1000 * 01, TIMER_ONE_SHOT);
                }
                break;

            case UPGRADE_FIRMWARE:
                is_silent_return = 1;
                INFO("upgrading firmware...");
                exec_sysupgrade_action();
                
                break;
            default:
                break;
        }
        
        if (!is_silent_return) {
            if (!is_root_loaded) {
                root = json_loads(msg->header->payload, 0, &error);
            }

            json_t* response_obj = json_object();

            json_object_set_new(response_obj, "return_code", json_integer(rc));
            json_object_set_new(response_obj, "timestamp", json_integer(get_unix_timestamp()));
            json_object_set_new(root, "data", response_obj);
            json_object_set_new(root, "msg_id", json_integer(UBUS_MSG_SEND_BACK_MQTT_2));
            char* data_str = json_dumps(root, JSON_COMPACT);
            task_post_dynamic_msg(TASK_REPLY, 1, (uint8_t*)data_str, strlen(data_str)+1);

            free(data_str);
            ak_msg_free(msg);
            json_decref(root);
        }

    }
    
}
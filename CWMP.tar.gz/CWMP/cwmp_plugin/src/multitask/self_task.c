#include "task_list.h"
#include <logger.h>
#include "utils.h"

#define SELF_CHECK 0
int counter_self_control = 0;
int self_memory = 0;
float mb_self_memory = 0;
q_msg_t gw_task_app_self_mailbox;


extern void* task_app_self_entry(void){
    wait_all_tasks_started();
    INFO("Self check handler task entry");
    char log_buffer[256];
    char log_dir[100];
    sprintf(log_dir, "%s%s", getenv("WORK_DIR"), "/self_memory");
    log_profile_t *log_profile = init_logger_file(log_dir, 5 * MB);
    ak_msg_t* msg;

    timer_set(TASK_SELF, SELF_CHECK, 1000 * 60, TIMER_PERIODIC);
    while(1) {
        msg = ak_msg_rev(TASK_SELF);
        switch (msg->header->sig)
        {
            case SELF_CHECK:
                self_memory = get_app_memory();
                mb_self_memory =  (float)(self_memory)/(1024.0);
                DEBUG("self memory: %f MB", mb_self_memory);
                // write log every 10 minutes
                if (counter_self_control == 10)
                {
                    memset(log_buffer, '\0', 256);
                    sprintf(log_buffer, "current memory usage: %f MB", mb_self_memory);
                    STORE_TRACE(log_buffer, log_profile);
                    counter_self_control = 0;
                }

                if (self_memory > (15 * 1024))
                {
                    memset(log_buffer, '\0', 256);
                    sprintf(log_buffer, "current memory usage: %f MB", mb_self_memory);
                    STORE_ERROR(log_buffer, log_profile);
                    STORE_ERROR("memory overflow, app restart", log_profile);
                    exit(1);
                }
            default:
                break;
        }
    }
    ak_msg_free(msg);
    close_log_profile(log_profile);
}
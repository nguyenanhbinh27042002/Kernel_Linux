#include "task_list.h"
#include "json_package.h"
#include "ubus_mapping.h"
#include <jansson.h>
#include <data_buffer.h>
#include "ipc.h"
#include <logger.h>

q_msg_t gw_task_app_reply_mailbox;

extern void* task_app_reply_entry(void){
    wait_all_tasks_started();
    sleep(1);
    INFO("[REPLY]  Reply handler task entry");

    /* Logger init */
    char log_dir[100];
    sprintf(log_dir, "%s%s", getenv("WORK_DIR"), "/unix_socket_response_log");
    log_profile_t* log_profile = init_logger_file(log_dir, 5 * MB);

    /* Init Unix Socket, Register to UBUS Broker*/
    char server_path[100];
    uint8_t* buffer[1000];
    protocol_msg_parser_t* proto_message_receiver = new_protocol_message();
    memset(buffer, 0, sizeof(buffer));  
    strcpy(server_path, getenv(SOCK_DIR_ENV));
    int client_sock = create_new_unix_connection(server_path);

    register_subscriber_name(client_sock, SOCK_NAME_PUB);
    recv(client_sock, buffer, sizeof(buffer), 0);
    parser_protocol_message(proto_message_receiver, (struct packet_t*)buffer);
    if(proto_message_receiver->optional_packet[0]->header.option == ACK_OPTION)
    {
        INFO("[REPLY] ACK received!");
    } else {
        ERROR("send failed, program exit...");
        clean_protocol_message(proto_message_receiver);
        close(client_sock);
        exit(-1);
    }

    /* Start waiting for another task message*/
    ak_msg_t* msg;
    while(1) {
        msg = ak_msg_rev(TASK_REPLY);
        char* data = (char*)msg->header->payload;

        json_error_t error;
        json_t* root = json_loads(data, 0, &error);

        /* Get dest peer info */
        char dst_peer[100];
        memset(dst_peer, '\0', 100);
        char* dst_peer_tmp = (char*)json_string_value(json_object_get(root, "dst_peer"));
        strcpy(dst_peer, dst_peer_tmp);

        /* Remove unessecsary info */
        json_object_del(root, "dst_peer");

        /* Dump json object into string */
        char* payload = json_dumps(root, JSON_COMPACT);
        INFO("data response: %s",payload);
        /* Send to UBUS Broker */
        struct packet_t *proto_message_sender = new_packet(CONTACT_IN_CLUSTER, 20000);
        add_optional_data_packet(proto_message_sender, DST_PEER, strlen(dst_peer), (uint8_t*)dst_peer);
        add_optional_data_packet(proto_message_sender, MESSAGE, strlen(payload), payload);
        int rc = check_error(send(client_sock, proto_message_sender, get_len_packet(proto_message_sender), 0), client_sock, "SEND ERROR", NOEXIT);
        if(rc == ERROR_CODE){
            STORE_ERROR("send message failed", log_profile);
        } else {
            STORE_INFO("send message successfully!", log_profile);
        }

        clean_packet(proto_message_sender);
        ak_msg_free(msg);
        json_decref(root);
        free(payload);
    }
}
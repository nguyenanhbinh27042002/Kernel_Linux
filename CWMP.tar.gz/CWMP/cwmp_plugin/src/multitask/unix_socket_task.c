#include "unix_socket_task.h"
#include "json_package.h"
#include "ipc.h"
#include <logger.h>
#include <jansson.h>
#include <unistd.h>
#include <data_buffer.h>
#include "ubus_mapping.h"

q_msg_t gw_task_app_unix_socket_mailbox;

#define STATUS_OK           0
#define FAIL                -1

extern void* task_app_unix_socket_entry(void)
{
    wait_all_tasks_started();
    INFO("Unix socket task entry");

    // init new log file
    char log_dir[100];
    sprintf(log_dir, "%s%s", getenv("WORK_DIR"), "/unix_socket_request_log");
    log_profile_t* log_profile = init_logger_file(log_dir, 5 * MB);
    STORE_TRACE("Unix task entry", log_profile);
    
    ak_msg_t* msg;
    int rc = STATUS_OK;

    char message_bytes[1000];
    char src_peer_bytes[100];
    char dst_peer_bytes[100];

    uint8_t* buffer[1000];
    char server_path[100];

    strcpy(server_path, getenv(SOCK_DIR_ENV));
    int client_sock = create_new_unix_connection(server_path);

    /* Register to UBUS Broker */
    protocol_msg_parser_t* proto_message_receiver = new_protocol_message();
    register_subscriber_name(client_sock, SOCK_NAME);
    recv(client_sock, buffer, sizeof(buffer), 0);
    parser_protocol_message(proto_message_receiver, (struct packet_t*)buffer);
    if(proto_message_receiver->optional_packet[0]->header.option == ACK_OPTION)
    {
        INFO("[UNIX_SOCKET] ACK received!");
    } else {
        ERROR("send failed, program exit...");
        clean_protocol_message(proto_message_receiver);
        close(client_sock);
    }

    while (1)
    {
        memset(buffer, 0, sizeof(buffer));
        INFO("waiting for new message...");
        check_error(recv(client_sock, buffer, sizeof(buffer), 0), client_sock, "RECV ERROR", EXIT);
        parser_protocol_message(proto_message_receiver, (struct packet_t*)buffer);
        INFO("new message received!");
        for (int index = 0; index < proto_message_receiver->packet_len; index++)
        {
            if (proto_message_receiver->optional_packet[index]->header.option == MESSAGE)
            {
                strncpy(message_bytes, proto_message_receiver->optional_packet[index]->data, 
                                proto_message_receiver->optional_packet[index]->header.data_len);
            }
            else if (proto_message_receiver->optional_packet[index]->header.option == SRC_PEER)
            {
                strncpy(src_peer_bytes, proto_message_receiver->optional_packet[index]->data, 
                                proto_message_receiver->optional_packet[index]->header.data_len);
            }
            else if (proto_message_receiver->optional_packet[index]->header.option == DST_PEER)
            {
                strncpy(dst_peer_bytes, proto_message_receiver->optional_packet[index]->data, 
                                proto_message_receiver->optional_packet[index]->header.data_len);
            }else {
                DEBUG("out case with id: %d", proto_message_receiver->optional_packet[index]->header.option);
            }
        }
        
        json_error_t error, error_res;
        json_t* root;
        json_t* response_obj;
        
        INFO("%s",message_bytes);
        STORE_INFO(message_bytes, log_profile);

        root = json_loads(message_bytes, 0, &error);
        json_object_set_new(root, "dst_peer", json_string(src_peer_bytes));

        char* message = json_dumps(root, JSON_COMPACT);
        if (root)
        { 
            int message_id = (int)json_integer_value(json_object_get(root, "msg_id"));
            switch (get_dest_task_handler_index(message_id))
            {
            case GET_INDEX:
		        task_post_dynamic_msg(TASK_APP_GET, message_id, (uint8_t*)message, strlen(message)+1);
                break;

            case SET_INDEX:
                task_post_dynamic_msg(TASK_APP_SET, message_id, (uint8_t*)message, strlen(message)+1);
                break;
            default:
                break;
            }
        }
        else
        {
            ERROR("json error on line %d: %s", error.line, error.text);
            int err_code = sending_error(client_sock, "can't decode json");
            check_error(err_code, NO_SOCK, "sending error failed! app exit", NOEXIT);
        }

        json_decref(root);
        free(message);
        memset(message_bytes    , '\0', 1000);
        memset(src_peer_bytes   , '\0', 100 );
        memset(dst_peer_bytes   , '\0', 100 );
    }

    clean_protocol_message(proto_message_receiver);
    ak_msg_free(msg);
    close(client_sock);
}
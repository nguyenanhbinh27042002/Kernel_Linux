#define _GNU_SOURCE
#define __USE_XOPEN

#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/types.h>
#include <arpa/inet.h>

char *execute_command(char *cmd)
{
  FILE *FileOpen;
  char *line = (char *)malloc(sizeof(char) * 100);
  FileOpen = popen(cmd, "r");
  fgets(line, 100, FileOpen);
  line[strcspn(line, "\r\n")] = '\0';

  pclose(FileOpen);
  return line;
}

void *execute_command_pointer(char *cmd, char *data)
{
  FILE *FileOpen;
  char *data_ptr = data;
  char line[100];
  FileOpen = popen(cmd, "r");
  fgets(line, 100, FileOpen);
  line[strcspn(line, "\r\n")] = '\0';
  strcpy(data_ptr, line);
  pclose(FileOpen);
}

char *execute_command_ubus(char *cmd)
{
  char line[254];
  char *main_string = NULL;
  char *temp_string = NULL;

  unsigned int size = 1;
  unsigned int strlength;

  FILE *excute_command;
  excute_command = popen(cmd, "r");
  if (excute_command == NULL)
  {
    printf("exec command failed\n");
    return NULL;
  }
  while (fgets(line, sizeof(line), excute_command) != NULL)
  {
    // get the string length of execute command return
    strlength = strlen(line);
    temp_string = realloc(main_string, size + strlength);
    if (temp_string == NULL)
    {
      free(main_string);
      printf("realloc failed\n");
      return NULL;
    }
    else
    {
      main_string = temp_string;
    }
    strcpy(main_string + size - 1, line);
    size = size + strlength;
  }
  pclose(excute_command);
  return main_string;
}

void append(char subject[], const char insert[], int pos)
{
  char buf[100] = {};
  strncpy(buf, subject, pos);
  int len = strlen(buf);
  strcpy(buf + len, insert);
  len += strlen(insert);
  strcpy(buf + len, subject + pos);
  strcpy(subject, buf);
}
int get_channel_by_fre(int fre)
{
  if ((fre <= 2484) && (fre >= 2412))
  {
    return fre == 2412 ? 1 : (((fre - 2412) / 5) + 1);
  }
  else if ((fre <= 5720) && (fre >= 5160))
  {
    return fre == 5160 ? 32 : (((fre - 5160) / 20) * 4 + 32);
  }
  else if ((fre <= 5885) && (fre >= 5745))
  {
    return fre == 5745 ? 149 : (((fre - 5745) / 20) * 4 + 149);
  }
  else
  {
    return 0;
  }
}

void append_character(char *s, char c)
{
  int len = strlen(s);
  s[len] = c;
  s[len + 1] = '\0';
}

int parseLine(char *line)
{
  // This assumes that a digit will be found and the line ends in " Kb".
  int i = strlen(line);
  const char *p = line;
  while (*p < '0' || *p > '9')
    p++;
  line[i - 3] = '\0';
  i = atoi(p);
  return i;
}

int get_app_memory()
{
  FILE *file = fopen("/proc/self/status", "r");
  int result = -1;
  char line[128];

  while (fgets(line, 128, file) != NULL)
  {
    if (strncmp(line, "VmRSS:", 6) == 0)
    {
      result = parseLine(line);
      break;
    }
  }
  fclose(file);
  return result;
}

void store_to_cache(char *path, json_t *log)
{
  FILE *file_cache = fopen(path, "w");
  json_dumpf(log, file_cache, JSON_COMPACT | JSON_REAL_PRECISION(4));
  fclose(file_cache);
}

unsigned long get_unix_timestamp() {
  return (unsigned long)time(NULL);
}

int is_file_path_exist(char* filePath) {
  if (access(filePath, F_OK) == 0) {
    return 1;
  } else {
    return 0;
  }
}

int remove_file(char* filePath) {
  if (remove(filePath) != 0){
    return -1;
  }
  return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include <unistd.h>
#include <stdbool.h>
#include "logger.h"
#include <jansson.h>
#include <data_buffer.h>

#include "ipc.h"

int check_error(int return_value, int client_sock, char *msg, bool isExit)
{
    if (return_value < 0)
    {
        printf("%s with return code: %d\n", msg, return_value);
        if (client_sock != 999)
        {
            close(client_sock);
        }
        if (isExit)
        {
            exit(ERROR_CODE);
        }
        return ERROR_CODE;
    }

    return 0;
}

static int set_unix_socket_path(struct sockaddr_un *saddr, const char *path_or_name)
{
    memset(&saddr->sun_path, 0, sizeof(saddr->sun_path));
    if (path_or_name[0] != 0)
    {
        strncpy(saddr->sun_path, path_or_name, sizeof(saddr->sun_path) - 1);
        return 0;
    }
    else
    {
        return ERROR_CODE;
    }
}

int create_new_unix_connection(char *server_path)
{
    int server_socket, len;
    server_socket = socket(AF_UNIX, SOCK_STREAM, 0);


    struct sockaddr_un server_sockaddr;
    memset(&server_sockaddr, 0, sizeof(struct sockaddr_un));
    server_sockaddr.sun_family = AF_UNIX;
    strcpy(server_sockaddr.sun_path, server_path);


    int rc = connect(server_socket, (struct sockaddr *)&server_sockaddr, sizeof(struct sockaddr_un));
    if (rc != 0) {
        close(server_socket);
        ERROR("connect to server socket failed with error code: %d", rc);
        exit(-1);
    }
    return server_socket;
}

void register_subscriber_name(int client_sock, char* name)
{
    struct packet_t *proto_message_sender = new_packet(REGISTER, 1000);
    add_optional_data_packet(proto_message_sender, NAME, strlen(name), (uint8_t*)name);
    check_error(send(client_sock, proto_message_sender, get_len_packet(proto_message_sender), 0), client_sock, "SEND ERROR", EXIT);
    clean_packet(proto_message_sender);
}

int sending_error(int client_sock, char *error_code)
{
    message_t *message = new_message(ERROR_MSG_CODE, "", error_code);
    char buffer[200];
    create_json_from_message(message, buffer);
    int err_code = check_error(send(client_sock, buffer, strlen(buffer), 0), client_sock, "SEND ERROR", NOEXIT);
    destroy_message(message);
    return err_code;
}

message_t *new_message(int message_id, char *return_key, char *data_json)
{
    message_t *message = (message_t *)malloc(sizeof(message_t));
    message->message_id = message_id;
    strncpy(message->return_key, return_key, strlen(return_key) + 1);
    message->data_json = (char *)malloc(sizeof(char) * (strlen(data_json) + 1));
    strncpy(message->data_json, data_json, strlen(data_json) + 1);
    return message;
}

void destroy_message(message_t *message)
{
    if (message)
    {
        if (message->data_json)
        {
            free(message->data_json);
            message->data_json = NULL;
        }
        free(message);
    }
}

void print_message(message_t *message)
{
    if (message)
    {
        INFO("message id: %d\n", message->message_id);
        INFO("return key: %s \n", message->return_key);
        if (message->data_json)
        {
            INFO("data json: %s \n", message->data_json);
        }
    }
}

void create_json_from_message(message_t *message, char *msg_string)
{
    if (message)
    {
        char *msg_ptr = msg_string;
        json_t *root = json_object();
        json_object_set_new(root, MSG_ID, json_integer(message->message_id));
        json_object_set_new(root, RETURN_K, json_string(message->return_key));
        json_object_set_new(root, DATA_JSON, json_string(message->data_json));
        char *json_string = json_dumps(root, JSON_COMPACT);
        strncpy(msg_ptr, json_string, strlen(json_string) + 1);
        free(json_string);
        json_decref(root);
    }
}

#include "json_package.h"
#include "get_info.h"
#include "utils.h"
#include "rc_code.h"

char* clients_json_package_ptr() {
    all_client_info_t* all_client_info = new_all_clients_info();
    int rc = get_all_client_info(all_client_info);
    if (rc == -1) {
        destroy_all_client_info(all_client_info);
        return NULL;
    }

    json_t *clients = json_array();
    json_t *root =  json_object();

    json_object_set_new(root, "total", json_integer(all_client_info->list_len));
    json_object_set_new(root, "self_serial_number", json_string(all_client_info->self_serial_number));

    int index = 0;
    for (index; index < all_client_info->list_len;index ++) {
        json_t* client = json_object();
        json_object_set_new(client, "mac_client"    , json_string(all_client_info->clients[index].mac_client));
        json_object_set_new(client, "parent_devices", json_string(all_client_info->clients[index].parrent_device));
        json_object_set_new(client, "band"          , json_string(all_client_info->clients[index].band));

        json_object_set_new(client, "signal"        , json_integer(all_client_info->clients[index].signal));
        json_object_set_new(client, "signal_avg"    , json_integer(all_client_info->clients[index].signal_avg));
        json_object_set_new(client, "connected_time", json_integer(all_client_info->clients[index].connected_time));

        json_object_set_new(client, "rx_bytes"      , json_integer(all_client_info->clients[index].rx_bytes));
        json_object_set_new(client, "rx_packets"    , json_integer(all_client_info->clients[index].rx_packets));
        json_object_set_new(client, "rx_bw"         , json_integer(all_client_info->clients[index].rx_bw));
        json_object_set_new(client, "rx_rate"       , json_integer(all_client_info->clients[index].rx_rate));
        json_object_set_new(client, "rx_mcs"        , json_integer(all_client_info->clients[index].rx_mcs));
        json_object_set_new(client, "rx_ht"         , json_integer(all_client_info->clients[index].rx_ht));
        json_object_set_new(client, "rx_vht"        , json_integer(all_client_info->clients[index].rx_vht));
        json_object_set_new(client, "rx_he"         , json_integer(all_client_info->clients[index].rx_he));
        json_object_set_new(client, "rx_short_gi"   , json_integer(all_client_info->clients[index].rx_short_gi));

        json_object_set_new(client, "tx_bytes"      , json_integer(all_client_info->clients[index].tx_bytes));
        json_object_set_new(client, "tx_packets"    , json_integer(all_client_info->clients[index].tx_packets));
        json_object_set_new(client, "tx_bw"         , json_integer(all_client_info->clients[index].tx_bw));
        json_object_set_new(client, "tx_failed"     , json_integer(all_client_info->clients[index].tx_failed));
        json_object_set_new(client, "tx_retries"    , json_integer(all_client_info->clients[index].tx_retries));
        json_object_set_new(client, "tx_rate"       , json_integer(all_client_info->clients[index].tx_rate));
        json_object_set_new(client, "tx_mcs"        , json_integer(all_client_info->clients[index].tx_mcs));
        json_object_set_new(client, "tx_ht"         , json_integer(all_client_info->clients[index].tx_ht));
        json_object_set_new(client, "tx_vht"        , json_integer(all_client_info->clients[index].tx_vht));
        json_object_set_new(client, "tx_he"         , json_integer(all_client_info->clients[index].tx_he));
        json_object_set_new(client, "tx_short_gi"   , json_integer(all_client_info->clients[index].tx_short_gi));

        json_array_append_new(clients, json_deep_copy(client));
        json_decref(client);
    }
    
    json_object_set_new(root, "clients", clients);
    json_object_set_new(root, "timestamp", json_integer(get_unixx_timestamp()));

    char* json_str = json_dumps(root, JSON_COMPACT | JSON_REAL_PRECISION(4));

    json_decref(root);
    destroy_all_client_info(all_client_info);
    return json_str;
}

char* interface_stat_package_ptr() {
    all_interface_stat_t* all_interfaces = new_all_interface_stat();
    int rc =  get_all_interface_stat(all_interfaces);
    if (rc != 0) {
        destroy_all_interface_stat(all_interfaces);
        return NULL;
    }

    json_t *root =  json_object();
    json_t *interfaces = json_array();

    int index = 0;
    
    for (index; index < MAX_INTERFACE_INDEX; index ++) {
        json_t* interface = json_object();

        json_object_set_new(interface, "interface"  , json_string(all_interfaces->interface[index].interface));
        json_object_set_new(interface, "tx_bytes"   , json_integer(all_interfaces->interface[index].tx_bytes));
        json_object_set_new(interface, "rx_bytes"   , json_integer(all_interfaces->interface[index].rx_bytes));
        json_object_set_new(interface, "tx_errors"  , json_integer(all_interfaces->interface[index].tx_errors));
        json_object_set_new(interface, "rx_errors"  , json_integer(all_interfaces->interface[index].rx_errors));
        json_object_set_new(interface, "tx_dropped" , json_integer(all_interfaces->interface[index].tx_dropped));
        json_object_set_new(interface, "rx_dropped" , json_integer(all_interfaces->interface[index].rx_dropped));
        json_object_set_new(interface, "rx_packets" , json_integer(all_interfaces->interface[index].rx_packets));
        json_object_set_new(interface, "tx_packets" , json_integer(all_interfaces->interface[index].tx_packets));
        json_object_set_new(interface, "multicast"  , json_integer(all_interfaces->interface[index].multicast));

        json_array_append_new(interfaces, json_deep_copy(interface));
        json_decref(interface);
    }

    json_object_set_new(root, "interfaces", interfaces);
    json_object_set_new(root, "timestamp", json_integer(get_unix_timestamp()));

    char* json_str = json_dumps(root, JSON_COMPACT | JSON_REAL_PRECISION(4));

    json_decref(root);
    destroy_all_interface_stat(all_interfaces);

    return json_str;
}

char* network_info_package_ptr() {
    network_info_t* network_info = new_network_info();
    get_all_network_info(network_info);

    json_t *root =  json_object();
    json_t *interfaces = json_array();

    json_object_set_new(root, "ip_wan", json_string(network_info->ip_wan));

    int index = 0;
    for (index; index < 2; index++) {
        json_t* interface = json_object();

        json_object_set_new(interface, "wlan_disabled"      , json_integer(network_info->interface[index].wlan_disabled));
        json_object_set_new(interface, "interface"          , json_string(network_info->interface[index].interface));
        json_object_set_new(interface, "wlan_ht"            , json_string(network_info->interface[index].wlan_ht));
        json_object_set_new(interface, "wlan_channel"       , json_string(network_info->interface[index].wlan_channel));
        json_object_set_new(interface, "wlan_encryption"    , json_string(network_info->interface[index].wlan_encryption));
        json_object_set_new(interface, "wlan_ssid"          , json_string(network_info->interface[index].wlan_ssid));
        json_object_set_new(interface, "wlan_pass"          , json_string(network_info->interface[index].wlan_pass));

        json_array_append_new(interfaces, json_deep_copy(interface));
        json_decref(interface);
    }
    json_object_set_new(root, "interfaces", interfaces);
    json_object_set_new(root, "timestamp", json_integer(get_unix_timestamp()));

    char* json_str = json_dumps(root, JSON_COMPACT | JSON_REAL_PRECISION(4));
    json_decref(root);

    destroy_network_info(network_info);
    return json_str;
}

char* system_info_package_ptr() {
    system_info_t* system_info = new_system_info();
    int rc = get_system_info(system_info);

    if (rc != 0) {
        destroy_system_info(system_info);
        return NULL;
    }

    json_t *root =  json_object();
    json_object_set_new(root, "cpu_usage"       , json_real(system_info->cpu_usage));
    json_object_set_new(root, "usage_memory"    , json_integer(system_info->usage_memory));
    json_object_set_new(root, "total_memory"    , json_integer(system_info->total_memory));
    json_object_set_new(root, "uptime"          , json_integer(system_info->uptime));
    json_object_set_new(root, "temperature"     , json_integer(system_info->temperature));
    json_object_set_new(root, "reboot_reason"   , json_string(system_info->reboot_reason));
    json_object_set_new(root, "reboot_subreason", json_string(system_info->reboot_subreason));
    json_object_set_new(root, "kernel_version"  , json_string(system_info->kernel_version));
    json_object_set_new(root, "hostname"        , json_string(system_info->hostname));
    json_object_set_new(root, "model_name"      , json_string(system_info->model_name));
    json_object_set_new(root, "serial_number"   , json_string(system_info->serial_number));
    json_object_set_new(root, "wan_mac"         , json_string(system_info->wan_mac));
    json_object_set_new(root, "firmware_version", json_string(system_info->firmware_version));
    json_object_set_new(root, "openwrt_version" , json_string(system_info->openwrt_version));
    json_object_set_new(root, "timestamp"       , json_integer(get_unix_timestamp()));
    json_object_set_new(root, "mesh_mode"       , json_integer(system_info->mesh_mode));
    json_object_set_new(root, "wan_mode"        , json_integer(system_info->wan_mode));

    char* json_str = json_dumps(root, JSON_COMPACT | JSON_REAL_PRECISION(4));

    json_decref(root);
    destroy_system_info(system_info);

    return json_str;
}

char* temperature_info_package_ptr() {
    all_sensor_history_t* sensors = new_sensors_history();
    int rc = get_all_sensors_history(sensors);
    if (rc != RC_SUCCESS) {
        destroy_all_sensor_history(sensors);
        return NULL;
    }

    json_t *root =  json_object();
    json_t *sensors_arr = json_array();
    int index = 0;
    for (index; index < 4; index++) {
        json_t* sensor = json_object();

        json_object_set_new(sensor, "sensor"            , json_string(sensors->sensors[index].sensor_name));
        json_object_set_new(sensor, "total_records"     , json_integer(sensors->sensors[index].list_len));
        json_t* timestamp_arr = json_array();
        json_t* temp_arr = json_array();
        int counter = 0;
        for (counter = 0; counter < sensors->sensors[index].list_len; counter ++) {
            json_array_append_new(timestamp_arr, json_integer(sensors->sensors[index].timestamp[counter]));
            json_array_append_new(temp_arr, json_integer(sensors->sensors[index].temperature[counter]));
        }
        json_object_set_new(sensor, "timestamps"    , timestamp_arr);
        json_object_set_new(sensor, "temperatures"  , temp_arr);

        json_array_append_new(sensors_arr, json_deep_copy(sensor));
        json_decref(sensor);
    }

    json_object_set_new(root, "sensors", sensors_arr);
    json_object_set_new(root, "timestamp", json_integer(get_unix_timestamp()));

    char* json_str = json_dumps(root, JSON_COMPACT | JSON_REAL_PRECISION(4));
    
    json_decref(root);
    destroy_all_sensor_history(sensors);
    return json_str;
}

char* network_topology_package_ptr() {
    network_topology_t* topo = new_topology();
    int rc = get_full_topology(topo);
    if (rc == RC_AGENT_NOT_SUPPORT) {
        json_t *root =  json_object();
        json_object_set_new(root, "topology", json_string("not supported in mode agent"));
        json_object_set_new(root, "timestamp", json_integer(get_unix_timestamp()));
        char* json_str = json_dumps(root, JSON_COMPACT | JSON_REAL_PRECISION(4));
        json_decref(root);
        destroy_network_topology(topo);
        return json_str;
    }

    json_t *root =  json_object();
    json_t *topo_arr = json_array();

    json_t* controller = json_object();
    json_object_set_new(controller, "ip"            , json_string(topo->controller.ip));
    json_object_set_new(controller, "hostname"      , json_string(topo->controller.hostname));
    json_object_set_new(controller, "mesh_role"     , json_string(topo->controller.mesh_role));
    json_object_set_new(controller, "parent_node"   , json_string(topo->controller.parent_node));
    json_object_set_new(controller, "self_mac"      , json_string(topo->controller.self_mac));
    json_object_set_new(controller, "total_client"  , json_integer(topo->controller.total_clients));

    json_t* clients_arr = json_array();
    int counter = 0;
    for (counter; counter < topo->controller.total_clients; counter ++ ) {
        json_t* temp = json_object();
        json_object_set_new(temp, "mac_connected"       , json_string(topo->controller.clients[counter].interface_mac));
        json_object_set_new(temp, "interface_connected" , json_string(topo->controller.clients[counter].interface_name));
        json_object_set_new(temp, "client_mac"          , json_string(topo->controller.clients[counter].client_mac));
        json_object_set_new(temp, "client_ip"           , json_string(topo->controller.clients[counter].client_ip));
        json_object_set_new(temp, "hostname"            , json_string(topo->controller.clients[counter].client_hostname));
        json_object_set_new(temp, "signal"              , json_integer(topo->controller.clients[counter].signal));
        json_object_set_new(temp, "tx_rate"             , json_integer(topo->controller.clients[counter].tx_rate));
        json_object_set_new(temp, "rx_rate"             , json_integer(topo->controller.clients[counter].rx_rate));
        json_object_set_new(temp, "tx_byte"             , json_integer(topo->controller.clients[counter].tx_byte));
        json_object_set_new(temp, "rx_byte"             , json_integer(topo->controller.clients[counter].rx_byte));

        json_array_append_new(clients_arr, json_deep_copy(temp));
        json_decref(temp);
    }

    json_object_set_new(controller, "clients"  , clients_arr);
    json_array_append_new(topo_arr, controller);

    int agent_counter = 0;
    for (agent_counter; agent_counter < topo->total_agent; agent_counter ++) {
        json_t* temp_agent = json_object();
        json_object_set_new(temp_agent, "ip"            , json_string(topo->agents[agent_counter].ip));
        json_object_set_new(temp_agent, "hostname"      , json_string(topo->agents[agent_counter].hostname));
        json_object_set_new(temp_agent, "mesh_role"     , json_string(topo->agents[agent_counter].mesh_role));
        json_object_set_new(temp_agent, "parent_node"   , json_string(topo->agents[agent_counter].parent_node));
        json_object_set_new(temp_agent, "self_mac"      , json_string(topo->agents[agent_counter].self_mac));
        json_object_set_new(temp_agent, "total_client"  , json_integer(topo->agents[agent_counter].total_clients));
        int counter = 0;
        json_t* clients_agent_arr = json_array();
        for (counter; counter < topo->agents[agent_counter].total_clients; counter ++ ) {
            json_t* temp = json_object();
            json_object_set_new(temp, "mac_connected"       , json_string(topo->agents[agent_counter].clients[counter].interface_mac));
            json_object_set_new(temp, "interface_connected" , json_string(topo->agents[agent_counter].clients[counter].interface_name));
            json_object_set_new(temp, "client_mac"          , json_string(topo->agents[agent_counter].clients[counter].client_mac));
            json_object_set_new(temp, "client_ip"           , json_string(topo->agents[agent_counter].clients[counter].client_ip));
            json_object_set_new(temp, "hostname"            , json_string(topo->agents[agent_counter].clients[counter].client_hostname));
            json_object_set_new(temp, "signal"              , json_integer(topo->agents[agent_counter].clients[counter].signal));
            json_object_set_new(temp, "tx_rate"             , json_integer(topo->agents[agent_counter].clients[counter].tx_rate));
            json_object_set_new(temp, "rx_rate"             , json_integer(topo->agents[agent_counter].clients[counter].rx_rate));
            json_object_set_new(temp, "tx_byte"             , json_integer(topo->agents[agent_counter].clients[counter].tx_byte));
            json_object_set_new(temp, "rx_byte"             , json_integer(topo->agents[agent_counter].clients[counter].rx_byte));

            json_array_append_new(clients_agent_arr, json_deep_copy(temp));
            json_decref(temp);
        }

        json_object_set_new(temp_agent, "clients"  , json_deep_copy(clients_agent_arr));
        json_array_append_new(topo_arr, json_deep_copy(temp_agent));
        json_decref(clients_agent_arr);
        json_decref(temp_agent);
    }

    json_object_set_new(root, "topology", topo_arr);
    json_object_set_new(root, "timestamp",json_integer(get_unix_timestamp()));

    char* json_str = json_dumps(root, JSON_COMPACT | JSON_REAL_PRECISION(4));
    json_decref(root);

    destroy_network_topology(topo);
    return json_str;
}
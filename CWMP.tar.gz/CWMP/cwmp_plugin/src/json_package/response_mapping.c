#include "json_package.h"
#include "ubus_mapping.h"

int get_dest_task_handler_index(int msg_id) {
    if (msg_id < MAX_GET_TOPIC)  {
        return GET_INDEX;
    } else if ((msg_id < MAX_SET_TOPIC)&&(msg_id > MAX_GET_TOPIC)) {
        return SET_INDEX;
    } else {
        return -1;
    }
}
#include "set_info.h"


int exec_reboot_action() {
    sync();
    int result = reboot(RB_AUTOBOOT); // initiate a system reboot

    if (result == -1) {
        perror("Reboot failed");
        return 1;
    } else {
        printf("Rebooting...\n");
        return 0;
    }
}
#include "set_info.h"
#include "utils.h"
#include "rc_code.h"
#include "logger.h"

#define MINIMUM_RAM_FRE 51200

// {
//     "mac": "30600a16ff9d",
//     "data": {
//         "msg_id": 7,
//         "data": {
//             "url": "https://cpek.fpt.vn/fs-tx/brQz9PfGqC/AP-AX3000C-0.3.4",
//             "fw_name":"AP-AX3000C-0.3.4"
//         }
//     },
//     "service": "cwmp_plugin"
// }

int exec_download_file_action(char* url, char* save_dest) {
    // check if file exist, if true -> remove file and start download new file
    if (is_file_path_exist(save_dest)) {
        int rc = remove_file(save_dest);
        if (rc == -1){
            return RC_FAIL_TO_RM_FILE;
        }
    }

    // get free memory & check if free enough
    char free_mem[12];
    long long free_mem_int = 0;
    memset(free_mem, '\0', 12);
    execute_command_pointer(GET_FREE_MEM, free_mem);
    sscanf(free_mem, "%lld", &free_mem_int);

    if (free_mem_int < MINIMUM_RAM_FRE) {
        int rc = system(SYNC_DROP_CACHES);
        if (rc != 0) {
            return RC_FAIL_TO_FREE_UP_RAM;
        }

        memset(free_mem, '\0', 12);
        execute_command_pointer(GET_FREE_MEM, free_mem);
        sscanf(free_mem, "%lld", &free_mem_int);
        if (free_mem_int < MINIMUM_RAM_FRE) {
            return RC_RC_RAM_NOT_ENOUGH;
        }
    }

    // start wget file in quiet mode
    char command[512];
    memset(command, '\0', 512);

    sprintf(command, WGET_WITH_DEST, url, save_dest, save_dest);
    DEBUG("command: %s", command);
    int rc = system(command);
    if (rc != 0) {
        return RC_FAIL_EXEC_WGET_FILE;
    }
    DEBUG("wget doen");

    if (!is_file_path_exist(save_dest)) {
        return RC_FAIL_DL_FILE;
    }
    
    return RC_SUCCESS;
}

int exec_sysupgrade_action() {
    char file_path[50];
    memset(file_path, '\0', 50);
    execute_command_pointer(GET_FIRMWARE_PATH, file_path);

    char command[128];
    memset(command, '\0', 128);
    sprintf(command, SYSUPGRADE, file_path);
    int rc = system(command);
    if (rc != 0) {
        return RC_FAIL_EXEC_WGET_FILE;
    }
    return RC_SUCCESS;
}
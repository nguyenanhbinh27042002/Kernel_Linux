#include "get_info.h"
#include "logger.h"
#include "json_package.h"

int main() {
    char ip[20];
    memset(ip, '\0', 20);
    int index = get_wan_index();
    DEBUG("index: %d", index);
    get_ip_wan(ip, index);
    DEBUG("ip: %s", ip);
}
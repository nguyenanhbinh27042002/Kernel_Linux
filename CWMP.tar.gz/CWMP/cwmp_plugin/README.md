# CWMP PLUGIN

> Source code of cwmp-plugin: simple plugin to controll and get info like portal of device.

## Genaral Information

### Dependencies

- [libclogger](https://github.com/Vienchau/c-logger): for debug and store log (static build with plugin).
- [libjansson](https://github.com/akheron/jansson): for json package (static build with plugin).
- [libak](https://github.com/FTEL-CPE-Lab/ak_linux_base): dynamic link, multithread lib.
- [libbuffer](https://git.fpt.net/inf/cpelab/CPE/CPE-Plugins/cluster_ubus): private in gitlab of CPELAB.

### Build

- Change toolchain prefix variable in Makefile: `CROSS_COMPILE`, `LIBRARY_PATH`,`INCLUDE_PATH`.

```bash
# example for ax3000c
make clean
make deploy-ax3000c
```
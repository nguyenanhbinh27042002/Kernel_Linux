#!/bin/sh
BUSYBOX_CMD=$WORK_DIR/bin/busybox
EXEC_DIR=$WORK_DIR/bin/cwmp_plugin
PID_FILE=$WORK_DIR/run/cwmp.pid

echo "cwmp_lugin start" > $WORK_DIR/init.log
echo "busybox: $BUSYBOX_CMD" >> $WORK_DIR/init.log
echo "exec directory: $EXEC_DIR" >> $WORK_DIR/init.log
echo "pid file: $PID_FILE" >> $WORK_DIR/init.log

mkdir $WORK_DIR/run

NOTIFY_URL="http://cpek.fpt.vn/plugin-history"
NOTIFY_AUTH="cpelablog:tRePRoWnPotHEDaYeRyArtEdOryDrifloAroGiBliOnjEcOMna"

post_notify_data() {
    MAC=$(ubus call system board | grep wan_mac | awk -F'["]' '{print tolower($4)}')
    curl -X POST -d "{\"mac_cpe\":\"$MAC\",\"plugin_name\":\"cwmp_plugin\",\"status\":$@}" -H "Content-Type: application/json" -u $NOTIFY_AUTH $NOTIFY_URL
}

# -S: start
# -b: background
# -q: quiet
# -m: make-pidfile
# -p: pidfile
# -v: version
# -x: exec

run_cwmp_plugin() {
    export LD_LIBRARY_PATH=$WORK_DIR/lib:/usr/mqtt/lib
    # export SOCK_DIR=/tmp/mqtt_info/sock
    echo "start run daemon cwmp_plugin"
    $BUSYBOX_CMD start-stop-daemon -S -b -q -m -p $PID_FILE -v -x $EXEC_DIR
}

start() {
    if [ ! -f $PID_FILE ]
    then
        run_cwmp_plugin
        post_notify_data "true"
    else
        PID=$(cat $PID_FILE)
        if [ ! -d /proc/$PID ]
        then
            run_cwmp_plugin
        fi
    fi
}

stop() {
    if [ -f $PID_FILE ]
    then
        PID=$(cat $PID_FILE)
        if [ -d /proc/$PID ]
        then
            kill -9 $PID
            post_notify_data "false"
        fi
        rm -f $PID_FILE
    fi
}


case "$1" in
    start)
        start
    ;;

    stop)
        stop
    ;;

    restart|reload|force-reload)
        $0 stop
        $0 start
    ;;

    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload}"
        exit 2
    ;;
esac

exit $?
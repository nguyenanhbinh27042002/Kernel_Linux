#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mosquitto.h "  
#define MAX_LINE_LENGTH 100


#define ADDRESS     "tcp://mqtt.server.address:1883"
#define CLIENTID    "ExampleClientPub"
#define TOPIC       "/home/anhbinh/Desktop/Working/Task_demo"
#define QOS         1
#define TIMEOUT     10000L



// Create structure for each line from data input
typedef struct {
    char category[10];
    int total;
    int used;
    int free;
    int shared;
    int buff_cache;
    int available;
} MemoryInfo;

void publishMemoryData(MemoryInfo *memory) {
    MQTTClient client;
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    int rc;

    // Initialize MQTT client
    MQTTClient_create(&client, ADDRESS, CLIENTID,
                      MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;

    // Connect to MQTT broker
    if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS) {
        printf("Failed to connect to MQTT broker, return code %d\n", rc);
        exit(-1);
    }

    // Prepare and publish memory data for each category
    char payload[MAX_LINE_LENGTH];
    MQTTClient_message pubmsg = MQTTClient_message_initializer;

    for (int i = 0; i < 2; i++) { // Assuming 2 categories: Mem and Swap
        snprintf(payload, sizeof(payload), "%s:\n"
                                          "  total: %d\n"
                                          "  used: %d\n"
                                          "  free: %d\n"
                                          "  shared: %d\n"
                                          "  buff/cache: %d\n"
                                          "  available: %d\n",
                 memory[i].category, memory[i].total, memory[i].used,
                 memory[i].free, memory[i].shared, memory[i].buff_cache,
                 memory[i].available);

        pubmsg.payload = payload;
        pubmsg.payloadlen = strlen(payload);
        pubmsg.qos = QOS;
        pubmsg.retained = 0;

        MQTTClient_publishMessage(client, TOPIC, &pubmsg, NULL);
    }

    // Disconnect MQTT client and clean up
    MQTTClient_disconnect(client, TIMEOUT);
    MQTTClient_destroy(&client);
}

int main() {
    char input_data[] = 
        "              total        used        free      shared  buff/cache   available\n"
        "Mem:        7970936     2016924     4157828      420988     1796184     5258376\n"
        "Swap:       8000508           0     8000508\n";

    char *line;
    char *token;
    MemoryInfo memory[2]; // Data for each line columns: Mem và Swap

    // Read each line from input data
    line = strtok(input_data, "\n");

    // Remove 1st line due to chosen for key from data input 
    line = strtok(NULL, "\n");

    int index = 0;
    while (line != NULL) {
        // Divide to each line
        token = strtok(line, " ");
        
        // Store the data for each (category)
        strcpy(memory[index].category, token);
        
        // Read value from data input
        for (int i = 0; i < 6; i++) {
            token = strtok(NULL, " ");
            switch (i) {
                case 0: // Column: total
                    memory[index].total = atoi(token);
                    break;
                case 1: // Column: used
                    memory[index].used = atoi(token);
                    break;
                case 2: // Column: free
                    memory[index].free = atoi(token);
                    break;
                case 3: // Column: shared
                    memory[index].shared = atoi(token);
                    break;
                case 4: // Column: buff/cache
                    memory[index].buff_cache = atoi(token);
                    break;
                case 5: // Column: Cavailable
                    memory[index].available = atoi(token);
                    break;
                default:
                    break;
            }
        }

        // Convert the next other line
        line = strtok(NULL, "\n");
        index++;
    }

    // Write the stored data
    for (int i = 0; i < 2; i++) { // The loop for 2 value from data_input: Mem và Swap
    // Print the processed data from input data  
        printf("%s:\n", memory[i].category);
        printf("  total: %d\n", memory[i].total);
        printf("  used: %d\n", memory[i].used);
        printf("  free: %d\n", memory[i].free);
        printf("  shared: %d\n", memory[i].shared);
        printf("  buff/cache: %d\n", memory[i].buff_cache);
        printf("  available: %d\n", memory[i].available);
    }

    return 0;
}
